package graduation.work.eatingalone;

import android.app.Activity;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.nfc.NdefMessage;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.Parcelable;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

public class MainActivity_User extends Activity implements View.OnClickListener{

    public static String TAG = "MainActivity_User";

    private TextView txt1, txt2, txt3, txt4, txt5, txtUserName, txtOrderMenu, txtOrderPrice, txtSeatNo, txtOrderDate;
    private Button btnMenu, btnPayment;

    private FirebaseDatabase mDatabase = null;
    private DatabaseReference mRefOrderInfo = null, mRefMenuInfo = null;
    private DataSnapshot mSnapOrderInfo = null, mSnapMenuInfo = null;

    private FragmentNFCRead mFragmentNfcRead;
    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;
    private IntentFilter writeTagFilters[];
    private Tag myTag;
    private String tagText = "";

    /**
     * 접속한 회원의 주문 정보가 있는지 판별
     */
    private boolean isOrderList = false;

    /**
     * Firebase에 저장된 내주문 정보의 고유 키값
     */
    private String  mOrderKey = "";

    private ProgressDialog mProgressDialog = null;

    private PopupDialog_User mPopupUserDlg;

    private long pressedTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_user);

        txt1 = findViewById(R.id.amu_txt1);
        txt2 = findViewById(R.id.amu_txt2);
        txt3 = findViewById(R.id.amu_txt3);
        txt4 = findViewById(R.id.amu_txt4);
        txt5 = findViewById(R.id.amu_txt5);

        txtUserName = findViewById(R.id.amu_txt_user_name);
        txtOrderMenu = findViewById(R.id.amu_txt_order_menu);
        txtOrderPrice = findViewById(R.id.amu_txt_order_price);
        txtSeatNo = findViewById(R.id.amu_txt_seat_no);
        txtOrderDate = findViewById(R.id.amu_txt_order_date);

        btnMenu = findViewById(R.id.amu_btn_menu);
        btnMenu.setOnClickListener(this);

        btnPayment = findViewById(R.id.amu_btn_payment);
        btnPayment.setOnClickListener(this);

        // Write a message to the database
        mDatabase = FirebaseDatabase.getInstance();
        mRefOrderInfo = mDatabase.getReference(Define.FB_ORDER_INFO);/*.child(Define.PHONE_NUM);*/

        // Read from the database
        mRefOrderInfo.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                mSnapOrderInfo = dataSnapshot;
                isOrderList = false;
                String FBUserId = "", FBUserName = "", FBOrderMenu = "", FBOrderPrice = "", FBSeatNo = "", FBOrderDate = "", FBPaymentComplete = "";

                for (DataSnapshot child : mSnapOrderInfo.getChildren()) {

                    String key = "";
                    key = child.getKey();

                    JSONObject jsonObj = new JSONObject((Map)child.getValue());
                    if(jsonObj == null)
                        continue;

                    try {
                        FBUserId = (String) jsonObj.get(Define.FB_ID);
                        FBUserName = (String) jsonObj.get(Define.FB_NAME);
                        FBOrderMenu = (String) jsonObj.get(Define.FB_ORDER_MENU);
                        FBOrderPrice = (String) jsonObj.get(Define.FB_ORDER_PRICE);
                        FBSeatNo = (String) jsonObj.get(Define.FB_ORDER_SEAT_NO);
                        FBOrderDate = (String) jsonObj.get(Define.FB_ORDER_DATE);
                        FBPaymentComplete = (String) jsonObj.get(Define.FB_PAYMENT_COMPLETE);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if(Define.USER_ID.equals(FBUserId) && FBPaymentComplete.equals("FALSE"))
                    {
                        isOrderList = true;
                        mOrderKey = key;
                        break;
                    }
                }

                if(isOrderList == true)
                {
                    btnPayment.setVisibility(View.VISIBLE);

                    txt1.setText("고객명: ");
                    txt2.setText("주문메뉴 : ");
                    txt3.setText("주문가격 : ");
                    txt4.setText("좌석번호 : ");
                    txt5.setText("주문시각: ");

                    txtUserName.setText(FBUserName);
                    txtOrderMenu.setText(FBOrderMenu);
                    txtOrderPrice.setText(FBOrderPrice);
                    txtSeatNo.setText(FBSeatNo);
                    txtOrderDate.setText(FBOrderDate);
                }

                else
                {
                    btnPayment.setVisibility(View.GONE);

                    txt1.setText("");
                    txt2.setText("");
                    txt3.setText("");
                    txt4.setText("");
                    txt5.setText("");

                    txtUserName.setText("");
                    txtOrderMenu.setText("");
                    txtOrderPrice.setText("");
                    txtSeatNo.setText("");
                    txtOrderDate.setText("");
                    //Toast.makeText(MainActivity_User.this, "주문내역이 없습니다.\n메뉴를 클릭해서 주문을 진행해 주세요!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });

        mRefMenuInfo = mDatabase.getReference(Define.FB_MENU_INFO);
        // Read from the database
        mRefMenuInfo.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                mSnapMenuInfo = dataSnapshot;
                QueryFirebaseThread thread = new QueryFirebaseThread();
                thread.setDaemon(true);
                thread.start();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter == null) {
            // Stop here, we definitely need NFC
            Toast.makeText(this, "This device doesn't support NFC.", Toast.LENGTH_LONG).show();
            finish();
        }
        readFromIntent(getIntent());

        pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
        IntentFilter tagDetected = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
        tagDetected.addCategory(Intent.CATEGORY_DEFAULT);
        writeTagFilters = new IntentFilter[] { tagDetected };
    }

    @Override
    public void onResume(){
        super.onResume();
        nfcAdapter.enableForegroundDispatch(this, pendingIntent, writeTagFilters, null);

        /**
         * 결제하기를 눌렀을 경우
         */
        if(mFragmentNfcRead != null) {
            mFragmentNfcRead.dismiss();
            mFragmentNfcRead = null;

            Intent intent = new Intent(this, PaymentActivity_User.class);
            intent.putExtra(Define.INTENT_USER_NAME, txtUserName.getText().toString());
            intent.putExtra(Define.INTENT_STORE_NAME, "혼밥남녀 1호점");
            intent.putExtra(Define.INTENT_PRODUCT_NAME, txtOrderMenu.getText().toString());
            intent.putExtra(Define.INTENT_CARD_NAME, "VISA Card");
            intent.putExtra(Define.INTENT_PAYMENT_PRICE, txtOrderPrice.getText().toString());

            /**
             * 어떤 사용자가 어떤 시간에 주문했는지를 보고 판별
             */
            intent.putExtra(Define.INTENT_ORDER_DATE, txtOrderDate.getText().toString());
            startActivity(intent);
        }
    }

    @Override
    public void onPause(){
        super.onPause();
        nfcAdapter.disableForegroundDispatch(this);
    }

    @Override
    public void onBackPressed() {
        if ( pressedTime == 0 ) {
            Toast.makeText(MainActivity_User.this, " 한 번 더 누르면 종료됩니다." , Toast.LENGTH_SHORT).show();
            pressedTime = System.currentTimeMillis();
        }
        else {
            int seconds = (int) (System.currentTimeMillis() - pressedTime);

            if ( seconds > 2000 ) {
                Toast.makeText(MainActivity_User.this, " 한 번 더 누르면 종료됩니다." , Toast.LENGTH_SHORT).show();
                pressedTime = 0 ;
            }
            else {
                // app 종료 시키기
                super.onBackPressed();
            }
        }
    }

    class QueryFirebaseThread extends Thread {

        public void run() {

            queryFirebase();
        }
    }

    private void queryFirebase() {

        ArrayList<MenuInfo> MenuArrayList = new ArrayList<>();

        runOnUiThread(new Runnable()
        {
            public void run()
            {
                if(mSnapMenuInfo.getChildrenCount() == 0)
                {
                    if(mProgressDialog != null)
                    {
                        mProgressDialog.dismiss();
                        mProgressDialog = null;
                    }
                    Toast.makeText(MainActivity_User.this, "메뉴가 존재하지 않습니다.\n메뉴를 추가해주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                else {
                    mProgressDialog = new ProgressDialog(MainActivity_User.this);
                    mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                    mProgressDialog.setMessage("메뉴리스트 업데이트중...\n잠시만 기다려 주십시오.");
                    mProgressDialog.setCanceledOnTouchOutside(false);
                    //mProgressDialog.setMax((int) mSnapMenuInfo.getChildrenCount());
                    mProgressDialog.show();
                }
            }
        });

        for (DataSnapshot child : mSnapMenuInfo.getChildren()) {

            String FBkey = "", FBMenu = "", FBPrice = "", FBImgUrl = "";
            FBkey = child.getKey();

            JSONObject jsonObj = new JSONObject((Map)child.getValue());
            if(jsonObj == null)
                continue;

            try {
                FBMenu = (String) jsonObj.get(Define.FB_MENU);
                FBPrice = (String) jsonObj.get(Define.FB_PRICE);
                FBImgUrl = (String) jsonObj.get(Define.FB_MENU_IMG_URL);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            MenuInfo item = new MenuInfo();
            item.setINDEX_KEY(FBkey);
            item.setMENU_NAME(FBMenu);
            item.setMENU_PRICE(FBPrice);
            item.setIMAGE_URL(FBImgUrl);
            Bitmap bitmap = getBitmapFromURL(FBImgUrl);
            item.setBITMAP(bitmap);
            MenuArrayList.add(item);
        }

        runOnUiThread(new Runnable() {
            public void run() {
                if (mProgressDialog != null) {
                    mProgressDialog.dismiss();
                    mProgressDialog = null;
                }
            }
        });

        Storage.setMenuInfoList(MenuArrayList);
    }

    /**
     * URL 주소로 Bitmap 변환 함수
     * @param imgUrl
     * @return
     */
    public Bitmap getBitmapFromURL(String imgUrl)
    {
        HttpURLConnection connection = null;
        try
        {
            URL url = new URL(imgUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e)
        {
            e.printStackTrace();
            return null;
        }
        finally
        {
            if(connection!=null)
                connection.disconnect();
        }
    }

    /******************************************************************************
     **********************************Read From NFC Tag***************************
     ******************************************************************************/
    private void readFromIntent(Intent intent) {
        String action = intent.getAction();
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(action)
                || NfcAdapter.ACTION_TECH_DISCOVERED.equals(action)
                || NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action)) {
            Parcelable[] rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
            NdefMessage[] msgs = null;
            if (rawMsgs != null) {
                msgs = new NdefMessage[rawMsgs.length];
                for (int i = 0; i < rawMsgs.length; i++) {
                    msgs[i] = (NdefMessage) rawMsgs[i];
                }
            }
            buildTagViews(msgs);
        }
    }

    private void buildTagViews(NdefMessage[] msgs)
    {
        if (msgs == null || msgs.length == 0)
            return;

//        String tagId = new String(msgs[0].getRecords()[0].getType());
        byte[] payload = msgs[0].getRecords()[0].getPayload();
        String textEncoding = ((payload[0] & 128) == 0) ? "UTF-8" : "UTF-16"; // Get the Text Encoding
        int languageCodeLength = payload[0] & 0063; // Get the Language Code, e.g. "en"
        // String languageCode = new String(payload, 1, languageCodeLength, "US-ASCII");

        try {
            // Get the Text
            tagText = new String(payload, languageCodeLength + 1, payload.length - languageCodeLength - 1, textEncoding);
        } catch (UnsupportedEncodingException e) {
            Log.e("UnsupportedEncoding", e.toString());
        }
    }

    private void showReadFragment() {

        mFragmentNfcRead = (FragmentNFCRead) getFragmentManager().findFragmentByTag(FragmentNFCRead.TAG);

        if (mFragmentNfcRead == null) {

            mFragmentNfcRead = FragmentNFCRead.newInstance();
        }
        mFragmentNfcRead.setCancelable(false);
        mFragmentNfcRead.show(getFragmentManager(),FragmentNFCRead.TAG);
    }

    @Override
    public void onClick(View view) {

        Intent intent = null;

        switch (view.getId())
        {
            case R.id.amu_btn_menu:
                if(isOrderList == true)
                {
                    Toast.makeText(this, "주문 내역이 존재합니다.\n결제완료후 주문해 주시기 바랍니다.", Toast.LENGTH_SHORT).show();
                    return;
                }

                mPopupUserDlg = new PopupDialog_User(this);
                mPopupUserDlg.show();
                mPopupUserDlg.setDialogResult(new PopupDialog_User.OnDialogResult() {

                    @Override
                    public void finish(int nAction) {

                        Intent intent = null;

                        switch (nAction)
                        {
                            case Define.ACTION_MENU_0:
                                intent = new Intent(MainActivity_User.this, NotiListActivity_User.class);
                                startActivity(intent);
                                break;
                            case Define.ACTION_MENU_1:
                                intent = new Intent(MainActivity_User.this, SeatActivity_User.class);
                                startActivity(intent);
                                break;
                        }
                    }
                });

                /*
                intent = new Intent(this, PopupActivity_User.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                */
                break;

            case R.id.amu_btn_payment:
                showReadFragment();
                break;
        }
    }
}
