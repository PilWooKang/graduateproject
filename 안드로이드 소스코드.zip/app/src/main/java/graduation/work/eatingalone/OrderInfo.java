package graduation.work.eatingalone;

public class OrderInfo {

    //주문 인덱스(키값)
    private String m_INDEX_KEY;

    //주문 회원 이름
    private String m_USER_NAME;

    //주문 메뉴
    private String m_ORDER_MENU;

    //주문 가격
    private String m_ORDER_PRICE;

    //주문 시각
    private String m_ORDER_DATE;

    //좌석 번호
    private String m_SEAT_NO;

    //결제 시각
    private String m_PAYMENT_DATE;

    //결제완료 유.무
    private String m_PAYMENT_COMPLETE;

    public void setINDEX_KEY(String INDEX_KEY)
    {
        this.m_INDEX_KEY = INDEX_KEY;
    }
    public void setUSER_NAME(String USER_NAME)
    {
        this.m_USER_NAME = USER_NAME;
    }
    public void setORDER_MENU(String ORDER_MENU)
    {
        this.m_ORDER_MENU = ORDER_MENU;
    }
    public void setORDER_PRICE(String ORDER_PRICE)
    {
        this.m_ORDER_PRICE = ORDER_PRICE;
    }
    public void setORDER_DATE(String ORDER_DATE)
    {
        this.m_ORDER_DATE = ORDER_DATE;
    }
    public void setSEAT_NO(String SEAT_NO)
    {
        this.m_SEAT_NO = SEAT_NO;
    }
    public void setPAYMENT_DATE(String PAYMENT_DATE)
    {
        this.m_PAYMENT_DATE = PAYMENT_DATE;
    }
    public void setPAYMENT_COMPLETE(String PAYMENT_COMPLETE)
    {
        this.m_PAYMENT_COMPLETE = PAYMENT_COMPLETE;
    }

    public String getINDEX_KEY(){
        return m_INDEX_KEY;
    }
    public String getUSER_NAME(){
        return m_USER_NAME;
    }
    public String getORDER_MENU(){
        return m_ORDER_MENU;
    }
    public String getORDER_PRICE(){
        return m_ORDER_PRICE;
    }
    public String getORDER_DATE(){
        return m_ORDER_DATE;
    }
    public String getSEAT_NO(){
        return m_SEAT_NO;
    }
    public String getPAYMENT_DATE(){
        return m_PAYMENT_DATE;
    }
    public String getPAYMENT_COMPLETE(){
        return m_PAYMENT_COMPLETE;
    }
}
