package graduation.work.eatingalone;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;

public class MenuListActivity_User extends Activity implements View.OnClickListener {

    public static String TAG = "MenuListActivity_User";

    private ListView listView;
    private Button btnSelect;

    private ArrayList<MenuInfo> mMenuArrayList = new ArrayList<>();
    private MenuListAdapter mListAdapter = null;
    private MenuInfo mSelItem = null;

    private String intentSeatNo = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_list_user);

        intentSeatNo = getIntent().getStringExtra(Define.INTENT_SEAT_NO);

        listView = findViewById(R.id.amlu_listview);
        listView.setOnItemClickListener(new ListViewItemClickListener());
        listView.requestFocusFromTouch();

        btnSelect = findViewById(R.id.amlu_btn_select);
        btnSelect.setOnClickListener(this);

        mMenuArrayList = Storage.getmMenuInfoList();
        mListAdapter = new MenuListAdapter(MenuListActivity_User.this, mMenuArrayList);
        listView.setAdapter(mListAdapter);
        mListAdapter.notifyDataSetChanged();
    }

    @Override
    public void onResume() {
        super.onResume();  // Always call the superclass method first
    }

    @Override
    public void onPause() {
        super.onPause();  // Always call the superclass method first
    }

    private class ListViewItemClickListener implements AdapterView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Intent intent = null;

            mListAdapter.setSelectedIndex(position);
            mListAdapter.notifyDataSetChanged();
            mSelItem = (MenuInfo) parent.getItemAtPosition(position);
        }
    }

    @Override
    public void onClick(View v) {

        Intent intent = null;

        switch (v.getId())
        {
            case R.id.amlu_btn_select:

                if(mSelItem == null)
                {
                    Toast.makeText(this, "주문하실 메뉴를 선택해주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }

                intent = new Intent(this, OrderActivity_User.class);
                intent.putExtra(Define.INTENT_ORDER_MENU, mSelItem.getMENU_NAME());
                intent.putExtra(Define.INTENT_ORDER_PRICE, mSelItem.getMENU_PRICE());
                intent.putExtra(Define.INTENT_SEAT_NO, intentSeatNo);
                startActivity(intent);
                finish();
                break;
        }
    }
}
