package graduation.work.eatingalone;

import android.Manifest;
import android.app.DialogFragment;
import android.content.Context;
import android.content.Intent;
import android.graphics.RectF;
import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.tech.Ndef;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.IOException;

public class FragmentNFCRead extends DialogFragment implements /*View.OnTouchListener*/View.OnClickListener{

    public static final String TAG = FragmentNFCRead.class.getSimpleName();

    public static FragmentNFCRead newInstance() {

        return new FragmentNFCRead();
    }

    private Button btnCancel;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NO_TITLE, R.style.Theme_AppCompat_Dialog);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_nfc_touch, container,false);
        initViews(view);

        Window window = getDialog().getWindow();
        window.setLayout(1200, 2000);
        window.setGravity(Gravity.CENTER);

        return view;
    }

    private void initViews(View view) {

        btnCancel = view.findViewById(R.id.fnt_btn_cancel);
        btnCancel.setOnClickListener(this);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    public void onNfcDetected(Ndef ndef){

        readFromNFC(ndef);
    }

    private void readFromNFC(Ndef ndef) {

        try {
            ndef.connect();
            NdefMessage ndefMessage = ndef.getNdefMessage();
            String message = new String(ndefMessage.getRecords()[0].getPayload());
            Log.d(TAG, "readFromNFC: "+message);
            //txtMessage.setText(message);
            ndef.close();

        } catch (IOException | FormatException e) {
            e.printStackTrace();

        }
    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.fnt_btn_cancel:
                dismiss();
                break;
        }
    }
}
