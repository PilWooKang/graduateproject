package graduation.work.eatingalone;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.BarChart;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

//import android.support.annotation.RequiresApi;

//월 매출
public class RevenueBarChartActivity extends Activity implements View.OnClickListener {

    public static String TAG = "RevenueBarChartActivity";

    private GraphicalView mChartView;

    private int mDeviceCnt = 0;

    //그래프에 표시될 월 표시
    private String[] mMonthList = new String[]{"1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"};

    //X축 바 최대 갯수
    private int mMaxXSize = 12;

    //최대 매출량(한달 기준)
    private double mMaxRevenue = 0;

    /**
     * 월별 매출량 해시맵
     */
    private HashMap<Integer, Integer> mRevenueMap = new HashMap<>();

    //setting chart value distance
    private int CharValueDistance = 70;

    //Bar Spacing
    private int BarSpacing = 1;

    private Button btnOk;

    private int LabelTxtSize = 40;

    /**
     * Firebase DB
     */
    private FirebaseDatabase mDatabase = null;
    private DatabaseReference mRefOrderInfo = null;
    private DataSnapshot mSnapOrderInfo = null;
    private ArrayList<OrderInfo> mPaymentInfoList = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_barchart_revenue);

        btnOk = findViewById(R.id.abr_btn_ok);
        btnOk.setOnClickListener(this);

        Intent intent = getIntent();

        // Write a message to the database
        mDatabase = FirebaseDatabase.getInstance();
        mRefOrderInfo = mDatabase.getReference(Define.FB_ORDER_INFO);/*.child(Define.PHONE_NUM);*/

        // Read from the database
        mRefOrderInfo.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                mSnapOrderInfo = dataSnapshot;
                mPaymentInfoList = new ArrayList<>();

                String FBKey = "", FBUserId = "", FBUserName = "", FBOrderMenu = "", FBOrderPrice = "", FBOrderDate = "", FBSeatNo = "", FBPaymentComplete = "", FBPaymentDate = "";

                for (DataSnapshot child : mSnapOrderInfo.getChildren()) {

                    FBKey = child.getKey();

                    JSONObject jsonObj = new JSONObject((Map)child.getValue());
                    if(jsonObj == null)
                        continue;

                    try {
                        FBUserId = (String) jsonObj.get(Define.FB_ID);
                        FBUserName = (String) jsonObj.get(Define.FB_NAME);
                        FBOrderMenu = (String) jsonObj.get(Define.FB_ORDER_MENU);
                        FBOrderPrice = (String) jsonObj.get(Define.FB_ORDER_PRICE);
                        FBOrderDate = (String) jsonObj.get(Define.FB_ORDER_DATE);
                        FBSeatNo = (String) jsonObj.get(Define.FB_ORDER_SEAT_NO);
                        FBPaymentComplete = (String) jsonObj.get(Define.FB_PAYMENT_COMPLETE);
                        FBPaymentDate = (String) jsonObj.get(Define.FB_PAYMENT_DATE);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    /**
                     * 결제가 완료된경우에만 결제내역 리스트에 추가한다.
                     */
                    if(FBPaymentComplete.equals("TRUE") == true)
                    {
                        OrderInfo item = new OrderInfo();
                        item.setINDEX_KEY(FBKey);
                        item.setUSER_NAME(FBUserName);
                        item.setORDER_MENU(FBOrderMenu);
                        item.setORDER_PRICE(FBOrderPrice);
                        item.setORDER_DATE(FBOrderDate);
                        item.setSEAT_NO(FBSeatNo);
                        item.setPAYMENT_DATE(FBPaymentDate);
                        item.setPAYMENT_COMPLETE(FBPaymentComplete);

                        mPaymentInfoList.add(item);
                    }
                }

                for(OrderInfo item : mPaymentInfoList)
                {
                    String paymentDate = item.getPAYMENT_DATE();
                    String splitDate[] = paymentDate.split("-");
                    int nMonth = 0;

                    String price = item.getORDER_PRICE();
                    price = price.replace("원", "");
                    price = price.replace(",", "");
                    int nPrice = Integer.parseInt(price);

                    if(splitDate != null && splitDate.length == 3)
                        nMonth = Integer.parseInt(splitDate[1]);

                    if(mRevenueMap.containsKey(nMonth) == false)
                        mRevenueMap.put(nMonth, nPrice);
                    else
                        mRevenueMap.put(nMonth, mRevenueMap.get(nMonth) + nPrice);
                }

                drawChart();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }

    private void drawChart() {

        // Creating an XYSeries for Income
        XYSeries TotalPaySeries = new XYSeries("월 매출");

        Collection values = mRevenueMap.values();//value값들 넣기
        mMaxRevenue = (Integer) Collections.max(values);

        for(int i=0; i<mMonthList.length; i++)
        {
            if(mRevenueMap.containsKey(i + 1))
            {
                int nPrice = mRevenueMap.get(i + 1);
                TotalPaySeries.add(i, nPrice);
            }
            else
            {
                TotalPaySeries.add(i, 0);
            }
        }

        /*
        // Adding data to Income and Expense Series
        for (int i = 0; i < mRevenueList.size(); i++) {

            TotalPaySeries.add(i, mRevenueList.get(i));
        }
        */

        // Creating a dataset to hold each series
        XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();

        // Adding Income Series to the dataset
        dataset.addSeries(TotalPaySeries);

        // Creating XYSeriesRenderer to customize incomeSeries
        XYSeriesRenderer incomeRenderer = new XYSeriesRenderer();

        /**
         * 그래프 막대 색상과 글자 색상
         */
        incomeRenderer.setColor(Color.parseColor("#ff0000")); //color of the graph set to cyan
        incomeRenderer.setFillPoints(true);
        incomeRenderer.setLineWidth(6);
        incomeRenderer.setDisplayChartValues(true);
        incomeRenderer.setDisplayChartValuesDistance(CharValueDistance); //setting chart value distance

        /**
         * 각 막대그래프의 수치
         */
        incomeRenderer.setChartValuesTextSize(40);

        // Creating a XYMultipleSeriesRenderer to customize the whole chart
        XYMultipleSeriesRenderer multiRenderer = new XYMultipleSeriesRenderer();
        multiRenderer.setOrientation(XYMultipleSeriesRenderer.Orientation.HORIZONTAL);
        multiRenderer.setXLabels(0);
        multiRenderer.setChartTitle("월 매출");
        multiRenderer.setXTitle("");
        multiRenderer.setYTitle("원");
        multiRenderer.setGridColor(Color.parseColor("#000000"));
        multiRenderer.setLabelsColor(Color.parseColor("#000000"));

        /***
         * Customizing graphs
         */
        //setting text size of the title
        multiRenderer.setChartTitleTextSize(50);
        multiRenderer.setAxesColor(Color.parseColor("#000000"));

        multiRenderer.setAxisTitleTextSize(40);

        //setting text size of the graph lable
        multiRenderer.setLabelsTextSize(LabelTxtSize);

        //setting zoom buttons visiblity
        multiRenderer.setZoomButtonsVisible(false);

        //setting pan enablity which uses graph to move on both axis
        multiRenderer.setPanEnabled(false, false);

        //setting click false on graph
        multiRenderer.setClickEnabled(false);

        //setting zoom to false on both axis
        multiRenderer.setZoomEnabled(false, false);

        //setting lines to display on y axis
        multiRenderer.setShowGridY(false);

        //setting lines to display on x axis
        multiRenderer.setShowGridX(false);

        //setting legend to fit the screen size
        multiRenderer.setFitLegend(false);

        //setting displaying line on grid
        multiRenderer.setShowGrid(false);

        //setting zoom to false
        multiRenderer.setZoomEnabled(true);

        //setting external zoom functions to false
        multiRenderer.setExternalZoomEnabled(true);

        //setting displaying lines on graph to be formatted(like using graphics)
        multiRenderer.setAntialiasing(true);

        //setting to in scroll to false
        multiRenderer.setInScroll(true);

        //setting to set legend height of the graph
        multiRenderer.setLegendHeight(30);

        //setting x axis label align
        multiRenderer.setXLabelsAlign(Paint.Align.CENTER);

        //setting y axis label to align
        multiRenderer.setYLabelsAlign(Paint.Align.LEFT);

        //setting text style
        multiRenderer.setTextTypeface("sans_serif", Typeface.NORMAL);

        //setting no of values to display in y axis
        multiRenderer.setYLabels(20);

        // setting y axis max value, Since i'm using static values inside the graph so i'm setting y max value to 4000.
        // if you use dynamic values then get the max y value and set here
        multiRenderer.setYAxisMax(mMaxRevenue + 10000);

        //setting used to move the graph on xaxiz to .5 to the right
        multiRenderer.setXAxisMin(-0.5);

        //setting max values to be display in x axis
        multiRenderer.setXAxisMax(mMaxXSize);

        //setting bar size or space between two bars
        multiRenderer.setBarSpacing(BarSpacing);

        //Setting background color of the graph to transparent
        multiRenderer.setBackgroundColor(Color.TRANSPARENT);

        //Setting margin color of the graph to transparent
//        multiRenderer.setMarginsColor(Color.BLUE);
        multiRenderer.setMarginsColor(Color.parseColor("#99cc66"));
        multiRenderer.setApplyBackgroundColor(true);
        multiRenderer.setXLabelsColor(Color.parseColor("#000000"));
        multiRenderer.setYLabelsColor(0, Color.parseColor("#000000"));
//        multiRenderer.setYLabelsColor(Color.parseColor("#000000"), 1);

        //setting the margin size for the graph in the order top, left, bottom, right
        multiRenderer.setMargins(new int[]{100, 100, 100, 100});
        for (int i = 0; i < mMonthList.length; i++) {

//            if(!mMonthName[i].equals(""))
                multiRenderer.addXTextLabel(i, mMonthList[i]);
        }

        // Adding incomeRenderer and expenseRenderer to multipleRenderer
        // Note: The order of adding dataseries to dataset and renderers to multipleRenderer
        // should be same
        multiRenderer.addSeriesRenderer(incomeRenderer);
//        multiRenderer.addSeriesRenderer(expenseRenderer);

        //this part is used to display graph on the xml
        LinearLayout layout = (LinearLayout) findViewById(R.id.abr_layout);

        //remove any views before u paint the chart
        layout.removeAllViews();

        //drawing bar chart
        mChartView = ChartFactory.getBarChartView(this, dataset, multiRenderer, BarChart.Type.STACKED);

        layout.addView(mChartView, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));
    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.abr_btn_ok:
                finish();
                break;
        }
    }
}
