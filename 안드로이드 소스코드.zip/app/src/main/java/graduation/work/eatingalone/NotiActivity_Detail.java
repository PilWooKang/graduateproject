package graduation.work.eatingalone;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class NotiActivity_Detail extends Activity implements View.OnClickListener{

    public static String TAG = "NotiActivity_Detail";

    private TextView txtTitle, txtContents, txtDate;
    private Button btnOk;

    private String intentTitle = "", intentContents = "", intentDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noti_detail);

        intentTitle = getIntent().getStringExtra(Define.INTENT_NOTI_TITLE);
        intentContents = getIntent().getStringExtra(Define.INTENT_NOTI_CONTENTS);
        intentDate = getIntent().getStringExtra(Define.INTENT_NOTI_DATE);

        txtTitle = findViewById(R.id.and_txt_title);
        if(intentTitle != null)
            txtTitle.setText(intentTitle);

        txtContents = findViewById(R.id.and_txt_contents);
        if(intentContents != null)
            txtContents.setText(intentContents);

        txtDate = findViewById(R.id.and_txt_date);
        if(intentDate != null)
            txtDate.setText(intentDate);

        btnOk = findViewById(R.id.and_btn_ok);
        btnOk.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.and_btn_ok:
                finish();
                break;
        }
    }
}
