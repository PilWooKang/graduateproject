package graduation.work.eatingalone;

import java.util.ArrayList;

public class Storage {

    private static ArrayList<MenuInfo> mMenuInfoList = new ArrayList<>();

    public static void setMenuInfoList(ArrayList<MenuInfo> menuinfolist)
    {
        mMenuInfoList = menuinfolist;
    }

    public static ArrayList<MenuInfo> getmMenuInfoList()
    {
        return mMenuInfoList;
    }
}
