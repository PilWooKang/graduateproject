package graduation.work.eatingalone;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

public class PaymentActivity_User extends Activity implements View.OnClickListener{

    public static String TAG = "PaymentActivity_User";

    private Button /*btnMenu,*/ btnConfirm;

    private TextView txtUserName, txtStoreName, txtProductName, txtCardName, txtPaymentPrice, txtPaymentDate;

    private String intentUserName = "", intentStoreName = "", intentProductName = "", intentCardName = "", intentPaymentPrice = "", intentOrderDate = "";

    private FirebaseDatabase mDatabase = null;
    private DatabaseReference mRefOrderInfo = null;
    private DataSnapshot mSnapOrderInfo = null;

    /**
     * Firebase에 저장된 내주문 정보의 고유 키값
     */
    private String  mOrderKey = "";

    private String mPaymentDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_user);

        intentUserName = getIntent().getStringExtra(Define.INTENT_USER_NAME);
        intentStoreName = getIntent().getStringExtra(Define.INTENT_STORE_NAME);
        intentProductName = getIntent().getStringExtra(Define.INTENT_PRODUCT_NAME);
        intentCardName = getIntent().getStringExtra(Define.INTENT_CARD_NAME);
        intentPaymentPrice = getIntent().getStringExtra(Define.INTENT_PAYMENT_PRICE);

        /**
         * 사용자 주문 시간을 가지고 Firebase의 결제 내역을 확인한다.
         */
        intentOrderDate = getIntent().getStringExtra(Define.INTENT_ORDER_DATE);

        txtUserName = findViewById(R.id.apu_txt_user_name);
        if(intentUserName != null)
            txtUserName.setText(intentUserName);

        txtStoreName = findViewById(R.id.apu_txt_store_name);
        if(intentStoreName != null)
            txtStoreName.setText(intentStoreName);

        txtProductName = findViewById(R.id.apu_txt_product_name);
        if(intentProductName != null)
            txtProductName.setText(intentProductName);

        txtCardName = findViewById(R.id.apu_txt_card_name);
        if(intentCardName != null)
            txtCardName.setText(intentCardName);

        txtPaymentPrice = findViewById(R.id.apu_txt_payment_price);
        if(intentPaymentPrice != null)
            txtPaymentPrice.setText(intentPaymentPrice);

        // 시스템으로부터 현재시간(ms) 가져오기
        long now = System.currentTimeMillis();
        // Data 객체에 시간을 저장한다.
        Date date = new Date(now);
        // 각자 사용할 포맷을 정하고 문자열로 만든다.
        SimpleDateFormat sdfNow = new SimpleDateFormat("yyyy-MM-dd kk:mm");
        mPaymentDate = sdfNow.format(date);

        txtPaymentDate = findViewById(R.id.apu_txt_payment_date);
        txtPaymentDate.setText(mPaymentDate);

        /*
        btnMenu = findViewById(R.id.apu_btn_menu);
        btnMenu.setOnClickListener(this);
        */

        btnConfirm = findViewById(R.id.apu_btn_confirm);
        btnConfirm.setOnClickListener(this);

        // Write a message to the database
        mDatabase = FirebaseDatabase.getInstance();
        mRefOrderInfo = mDatabase.getReference(Define.FB_ORDER_INFO);/*.child(Define.PHONE_NUM);*/

        // Read from the database
        mRefOrderInfo.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                mSnapOrderInfo = dataSnapshot;

                String FBUserId = "", FBUserName = "", FBOrderMenu = "", FBOrderPrice = "", FBSeatNo = "", FBOrderDate = "", FBPaymentComplete = "";

                for (DataSnapshot child : mSnapOrderInfo.getChildren()) {

                    String key = "";
                    key = child.getKey();

                    JSONObject jsonObj = new JSONObject((Map)child.getValue());
                    if(jsonObj == null)
                        continue;

                    try {
                        FBUserId = (String) jsonObj.get(Define.FB_ID);
                        FBUserName = (String) jsonObj.get(Define.FB_NAME);
                        FBOrderMenu = (String) jsonObj.get(Define.FB_ORDER_MENU);
                        FBOrderPrice = (String) jsonObj.get(Define.FB_ORDER_PRICE);
                        FBSeatNo = (String) jsonObj.get(Define.FB_ORDER_SEAT_NO);
                        FBOrderDate = (String) jsonObj.get(Define.FB_ORDER_DATE);
                        FBPaymentComplete = (String) jsonObj.get(Define.FB_PAYMENT_COMPLETE);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    /**
                     * 회원ID가 일치하며
                     */
                    if(Define.USER_ID.equals(FBUserId))
                    {
                        /**
                         * 주문시간이 일치하고, 결제완료가 아닌경우
                         */
                        if(FBOrderDate.equals(intentOrderDate) && FBPaymentComplete.equals("FALSE"))
                        {
                            mOrderKey = key;
                            break;
                        }
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }

    public void sendSMS(String smsNumber, String smsText){
        PendingIntent sentIntent = PendingIntent.getBroadcast(this, 0, new Intent("SMS_SENT_ACTION"), 0);
        PendingIntent deliveredIntent = PendingIntent.getBroadcast(this, 0, new Intent("SMS_DELIVERED_ACTION"), 0);

        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                switch(getResultCode()){
                    case Activity.RESULT_OK:
                        // 전송 성공
                        //Toast.makeText(MainActivity_User.this, "전송 완료", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                        // 전송 실패
                        //Toast.makeText(MainActivity_User.this, "전송 실패", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NO_SERVICE:
                        // 서비스 지역 아님
                        //Toast.makeText(MainActivity_User.this, "서비스 지역이 아닙니다", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_RADIO_OFF:
                        // 무선 꺼짐
                        //Toast.makeText(MainActivity_User.this, "무선(Radio)가 꺼져있습니다", Toast.LENGTH_SHORT).show();
                        break;
                    case SmsManager.RESULT_ERROR_NULL_PDU:
                        // PDU 실패
                        //Toast.makeText(MainActivity_User.this, "PDU Null", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        }, new IntentFilter("SMS_SENT_ACTION"));

        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                switch (getResultCode()){
                    case Activity.RESULT_OK:
                        // 도착 완료
                        //Toast.makeText(MainActivity_User.this, "SMS 도착 완료", Toast.LENGTH_SHORT).show();
                        //Toast.makeText(PaymentInfoActivity_User.this, "결제가 완료되었습니다.", Toast.LENGTH_SHORT);
                        break;
                    case Activity.RESULT_CANCELED:
                        // 도착 안됨
                        //Toast.makeText(MainActivity_User.this, "SMS 도착 실패", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        }, new IntentFilter("SMS_DELIVERED_ACTION"));

        SmsManager mSmsManager = SmsManager.getDefault();
        mSmsManager.sendTextMessage(smsNumber, null, smsText, sentIntent, deliveredIntent);
    }

    @Override
    public void onClick(View view) {

        Intent intent = null;

        switch (view.getId())
        {
            /*
            case R.id.apu_btn_menu:
                intent = new Intent(this, PopupActivity_Admin.class);
                startActivity(intent);
                break;
                */

            case R.id.apu_btn_confirm:

                if(mOrderKey.equals("") == true)
                {
                    Toast.makeText(this, "결제 준비중입니다.\n다시 시도해 주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                else
                {
                    String smsTxt = intentUserName + " " +intentStoreName + " " + intentCardName + " " +intentProductName + " " + intentPaymentPrice + " " + mPaymentDate;
                    sendSMS(Define.USER_PHONE, smsTxt);
                    mRefOrderInfo.child(mOrderKey).child(Define.FB_PAYMENT_DATE).setValue(mPaymentDate);
                    mRefOrderInfo.child(mOrderKey).child(Define.FB_PAYMENT_COMPLETE).setValue("TRUE");
                    Toast.makeText(this, "결제가 완료되었습니다.\n결제내역은 SMS를 통해 확인 가능하십니다.", Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;
        }
    }
}
