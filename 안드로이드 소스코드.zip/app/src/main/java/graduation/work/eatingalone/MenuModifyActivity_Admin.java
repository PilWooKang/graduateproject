package graduation.work.eatingalone;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;

/**
 * 메뉴 수정/삭제
 */
public class MenuModifyActivity_Admin extends Activity implements View.OnClickListener {

    public static String TAG = "MenuModifyActivity_Admin";

    private EditText edtMenu, edtPrice;
    private ImageView imageView;
    private Button btnImgUpload, btnModify, btnDelete;

    /**
     * Firebase DB
     */
    private FirebaseDatabase mDatabase = null;
    private DatabaseReference mRefMenuInfo = null;
    private DataSnapshot mSnapMenuInfo = null;
    private ArrayList<Integer> mMenuKeyList = new ArrayList<Integer>();
    private String mMenu = "", mPrice = "";

    /**
     * Firebase Storage
     */
    private StorageReference mStorage = null;
    private StorageReference mStorageMenuInfo = null;

    private Uri mImageUri = null;
    private ProgressDialog mProgressDialog = null;

    private String intentIndexKey = "", intentMenu = "", intentPrice = "", intentImgUrl = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_modify);

        StrictMode.enableDefaults();

        intentIndexKey = getIntent().getStringExtra(Define.INTENT_MENU_INDEX_KEY);
        intentMenu = getIntent().getStringExtra(Define.INTENT_MENU_NAME);
        intentPrice = getIntent().getStringExtra(Define.INTENT_MENU_PRICE);
        intentImgUrl = getIntent().getStringExtra(Define.INTENT_MENU_IMG_URL);

        edtMenu = findViewById(R.id.amm_edt_menu);
        if(intentMenu != null)
            edtMenu.setText(intentMenu);

        edtPrice = findViewById(R.id.amm_edt_price);
        if(intentPrice != null)
            edtPrice.setText(intentPrice);

        imageView = findViewById(R.id.amm_imageview);
        if(intentImgUrl != null)
        {
            getBitmapThread thread = new getBitmapThread(intentImgUrl);
            thread.setDaemon(true);
            thread.start();

            /*
            Bitmap bitmap = getBitmapFromURL(intentImgUrl);
            imageView.setImageBitmap(bitmap);
            */
        }

        btnImgUpload = findViewById(R.id.amm_btn_img_upload);
        btnImgUpload.setOnClickListener(this);

        btnModify = findViewById(R.id.amm_btn_modify);
        btnModify.setOnClickListener(this);

        btnDelete = findViewById(R.id.amm_btn_delete);
        btnDelete.setOnClickListener(this);

        // Write a message to the database
        mDatabase = FirebaseDatabase.getInstance();

        mRefMenuInfo = mDatabase.getReference(Define.FB_MENU_INFO);
        // Read from the database
        mRefMenuInfo.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                mSnapMenuInfo = dataSnapshot;

                mMenuKeyList = new ArrayList<Integer>();
                for (DataSnapshot child : mSnapMenuInfo.getChildren()) {

                    String key = "";
                    key = child.getKey();
                    mMenuKeyList.add(Integer.parseInt(key));
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });

        mStorage = FirebaseStorage.getInstance().getReference();
        mStorageMenuInfo = mStorage.child(Define.FB_MENU_INFO);
    }

    class getBitmapThread extends Thread {

        private  String mImgUrl;
        private Bitmap mBitmap;

        public getBitmapThread(String imgUrl)
        {
            mImgUrl = imgUrl;
        }

        public void run() {

            mBitmap = getBitmapFromURL(mImgUrl);

            runOnUiThread(new Runnable()
            {
                public void run()
                {
                    imageView.setImageBitmap(mBitmap);
                }
            });
        }
    }

    /**
     * 앨범에서 이미지 가져오기
     */
    public void doTakeAlbumAction()
    {
        //앨범 호출
        Intent intent = new Intent(Intent.ACTION_PICK);

        intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        startActivityForResult(intent, Define.REQ_PICK_FROM_ALBUM);
    }

    /**
     * URL 주소로 Bitmap 변환 함수
     * @param imgUrl
     * @return
     */
    public Bitmap getBitmapFromURL(String imgUrl)
    {
        HttpURLConnection connection = null;
        try
        {
            URL url = new URL(imgUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e)
        {
            e.printStackTrace();
            return null;
        }
        finally
        {
            if(connection!=null)
                connection.disconnect();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK)
            return;

        switch (requestCode) {

            case Define.REQ_PICK_FROM_ALBUM: {
                //이후의 처리가 카메라와 같으므로 일단 break 없이 진행합니다.
                //실제 코드에서는 좀더 합리적인 방법을 선택하시기 바랍니다.
                mImageUri = data.getData();

                Bitmap bitmapOrg = null;
                try {
                    bitmapOrg = MediaStore.Images.Media.getBitmap(getContentResolver(), mImageUri);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                //배치해놓은 ImageView에 set
                if(bitmapOrg != null)
                    imageView.setImageBitmap(bitmapOrg);

                //bitmapOrg = MediaStore.Images.Media.getBitmap(getContentResolver(), urione);

                //이미지를 가져온 이후의 리사이즈할 이미지 크기를 결정합니다.
                //이후에 이미지 크롭 어플리케이션을 호출하게 됩니다.
                /*
                Intent intent = new Intent("com.android.camera.action.CROP");
                intent.setDataAndType(mImageUri, "image/*");

                //CROP할 이미지를 200*200 크기로 저장
                intent.putExtra("outputX", 500);    //CROP한 이미지의 X축 크기
                intent.putExtra("outputY", 500);    //CROP한 이미지의 X축 크기
                intent.putExtra("aspectX", 1);      //CROP 박스의 X축 비율
                intent.putExtra("aspectY", 1);      //CROP 박스의 Y축 비율
                intent.putExtra("scale", true);      //CROP 박스의 Y축 비율
                intent.putExtra("return-data", true);
                startActivityForResult(intent, Define.REQ_CROP_FROM_IMAGE);    //CROP_FROM_CAMERA case문 이동
                */
            }
            break;

            /*
            case Define.REQ_CROP_FROM_IMAGE: {

                //크롭이 된 이후의 이미지를 넘겨받는다.
                //이미지뷰에 이미지를 보여주거나 부가적인 작업 이후에
                //임시파일을 삭제한다.
                if ( resultCode != RESULT_OK )
                    return;

                final Bundle extras = data.getExtras();

                mImageUri = data.getData();

                if(mImageUri == null)
                    return;

                Bitmap bitmapOrg = null;
                try {
                    bitmapOrg = MediaStore.Images.Media.getBitmap(getContentResolver(), mImageUri);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                //배치해놓은 ImageView에 set
                if(bitmapOrg != null)
                    imgView.setImageBitmap(bitmapOrg);
            }
            break;
            */
        }
    }

    public void openDeleteDlg(){

        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
        alertDialogBuilder.setMessage("'메뉴를 삭제 하시겠습니까?");
        alertDialogBuilder.setCancelable(false);
        alertDialogBuilder.setPositiveButton("삭제하기",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {

                        mRefMenuInfo.child(intentIndexKey).removeValue();
                        mStorageMenuInfo.child(intentIndexKey).delete();
                        Toast.makeText(MenuModifyActivity_Admin.this, "메뉴 삭제 완료", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
        alertDialogBuilder.setNegativeButton("취소",new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    @Override
    public void onClick(View v) {

        Intent intent = null;

        switch (v.getId())
        {
            case R.id.amm_btn_img_upload:
                doTakeAlbumAction();
                break;

            case R.id.amm_btn_modify:

                mMenu = edtMenu.getText().toString();
                mPrice = edtPrice.getText().toString();
                Bitmap bitmap = ((BitmapDrawable)imageView.getDrawable()).getBitmap();

                if(mSnapMenuInfo == null)
                {
                    Toast.makeText(this, "Firebase 정보 동기화중", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(mMenu.equals(""))
                {
                    Toast.makeText(this, "메뉴명을 입력해 주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(mPrice.equals(""))
                {
                    Toast.makeText(this, "메뉴 가격을 입력해 주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(bitmap == null)
                {
                    Toast.makeText(this, "이미지 파일을 업로드해주세요..", Toast.LENGTH_LONG).show();
                    return;
                }

                /*
                if (mImageUri == null) {
                    Toast.makeText(this, "이미지 파일을 업로드해주세요..", Toast.LENGTH_LONG).show();
                    return;
                }
                */

                mProgressDialog = new ProgressDialog(this);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.setMessage("메뉴 업로드중입니다.\n잠시만 기다려 주십시오.");
                mProgressDialog.setCancelable(false);
                mProgressDialog.setCanceledOnTouchOutside(false);
                mProgressDialog.show();

                if(mImageUri == null)
                {
                    mProgressDialog.dismiss();
                    mProgressDialog = null;

                    mRefMenuInfo.child(intentIndexKey).child(Define.FB_MENU).setValue(mMenu);
                    mRefMenuInfo.child(intentIndexKey).child(Define.FB_PRICE).setValue(mPrice);
                    Toast.makeText(MenuModifyActivity_Admin.this, "메뉴 수정 완료", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }

                mStorageMenuInfo.child(intentIndexKey).putFile(mImageUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                // Get a URL to the uploaded content
                                //Uri downloadUrl = taskSnapshot.getDownloadUrl();
                                if(mProgressDialog != null)
                                {
                                    mProgressDialog.dismiss();
                                    mProgressDialog = null;

                                    mRefMenuInfo.child(intentIndexKey).child(Define.FB_MENU).setValue(mMenu);
                                    mRefMenuInfo.child(intentIndexKey).child(Define.FB_PRICE).setValue(mPrice);
                                    mRefMenuInfo.child(intentIndexKey).child(Define.FB_MENU_IMG_URL).setValue(taskSnapshot.getDownloadUrl().toString());

                                    Toast.makeText(MenuModifyActivity_Admin.this, "메뉴 수정 완료", Toast.LENGTH_SHORT).show();
                                    finish();
                                }
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // Handle unsuccessful uploads
                                if(mProgressDialog != null)
                                {
                                    mProgressDialog.dismiss();
                                    mProgressDialog = null;
                                    Toast.makeText(MenuModifyActivity_Admin.this, "메뉴 수정 실패\n다시 시도해 주세요.", Toast.LENGTH_SHORT).show();
                                    //finish();
                                }
                            }
                        });

                break;

            case R.id.amm_btn_delete:
                openDeleteDlg();
                break;
        }
    }
}
