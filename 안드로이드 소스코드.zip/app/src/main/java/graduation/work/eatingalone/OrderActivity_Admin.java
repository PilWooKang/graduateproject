package graduation.work.eatingalone;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class OrderActivity_Admin extends Activity implements View.OnClickListener{

    public static String TAG = "OrderActivity_Admin";

    private TextView txtUserName, txtOrderMenu, txtOrderPrice, txtOrderDate, txtSeatNo;
    private Button btnOk;

    private String intentUserName = "", intentOrderMenu = "", intentOrderPrice = "", intentSeatNo = "", intentOrderDate = "";

    private FirebaseDatabase mDatabase = null;
    private DatabaseReference mRefOrderInfo = null;
    private DataSnapshot mSnapOrderInfo = null;
    private ArrayList<Integer> mKeyListOrder = new ArrayList<Integer>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_admin);

        intentUserName = getIntent().getStringExtra(Define.INTENT_USER_NAME);
        intentOrderMenu = getIntent().getStringExtra(Define.INTENT_ORDER_MENU);
        intentOrderPrice = getIntent().getStringExtra(Define.INTENT_ORDER_PRICE);
        intentOrderDate = getIntent().getStringExtra(Define.INTENT_ORDER_DATE);
        intentSeatNo = getIntent().getStringExtra(Define.INTENT_SEAT_NO);

        txtUserName = findViewById(R.id.aoa_txt_user_name);
        if(intentUserName != null)
            txtUserName.setText(intentUserName);

        txtOrderMenu = findViewById(R.id.aoa_txt_order_menu);
        if(intentOrderMenu != null)
            txtOrderMenu.setText(intentOrderMenu);

        txtOrderPrice = findViewById(R.id.aoa_txt_menu_price);
        if(intentOrderPrice != null)
            txtOrderPrice.setText(intentOrderPrice);

        txtOrderDate = findViewById(R.id.aoa_txt_order_date);
        if(intentOrderDate != null)
            txtOrderDate.setText(intentOrderDate);

        txtSeatNo = findViewById(R.id.aoa_txt_seat_no);
        if(intentSeatNo != null) {
            txtSeatNo.setText(intentSeatNo);
        }

        btnOk = findViewById(R.id.aoa_btn_ok);
        btnOk.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.aoa_btn_ok:
                finish();
                break;
        }
    }
}
