package graduation.work.eatingalone;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class OrderInfoListAdapter extends BaseAdapter {

    private ArrayList<OrderInfo> mArrayList = null;
    private ListViewHolder viewHolder = null;
    private Context mContext = null;
    private LayoutInflater inflater = null;

    //리스트에서 선택한 Position
    private int mSelectedPosition = -1;

    private class ListViewHolder {

        //레이아웃
        public LinearLayout layout;

        //메뉴명
        public TextView txtMenu;

        //주문가격
        public TextView txtPrice;

        //주문시각
        public TextView txtDate;

        //좌석번호
        public TextView txtSeatNo;
    }

    public OrderInfoListAdapter(Context context, ArrayList<OrderInfo> arrays){

        this.mContext = context;
        this.inflater = LayoutInflater.from(context);
        this.mArrayList = arrays;
    }

    @Override
    public int getCount() {
        return mArrayList.size();
    }

    @Override
    public OrderInfo getItem(int position) {
        return mArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public void setSelectedIndex(int index) {
        mSelectedPosition = index;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = convertView;

        if(v == null){
            viewHolder = new ListViewHolder();
            v = inflater.inflate(R.layout.listview_item_order, null);

            viewHolder.layout = v.findViewById(R.id.item_layout);
            viewHolder.txtMenu = v.findViewById(R.id.item_txt_order_menu);
            viewHolder.txtPrice = v.findViewById(R.id.item_txt_order_price);
            viewHolder.txtDate= v.findViewById(R.id.item_txt_order_date);
            viewHolder.txtSeatNo = v.findViewById(R.id.item_txt_seat_no);

            v.setTag(viewHolder);

        }else {
            viewHolder = (ListViewHolder)v.getTag();
        }

        if(mSelectedPosition == position)
        {
            viewHolder.layout.setBackgroundColor(Color.YELLOW);
        }
        else
        {
            viewHolder.layout.setBackgroundColor(Color.WHITE);
        }

        viewHolder.layout.setTag(position);

        viewHolder.txtMenu.setTag(position);
        viewHolder.txtMenu.setText(getItem(position).getORDER_MENU());

        viewHolder.txtPrice.setTag(position);
        viewHolder.txtPrice.setText(getItem(position).getORDER_PRICE());

        viewHolder.txtDate.setTag(position);
        viewHolder.txtDate.setText(getItem(position).getORDER_DATE());

        viewHolder.txtSeatNo.setTag(position);
        viewHolder.txtSeatNo.setText(getItem(position).getSEAT_NO());

        return v;
    }
}
