package graduation.work.eatingalone;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class PaymentInfoListAdapter extends BaseAdapter {

    private ArrayList<OrderInfo> mArrayList = null;
    private ListViewHolder viewHolder = null;
    private Context mContext = null;
    private LayoutInflater inflater = null;

    //리스트에서 선택한 Position
    private int mSelectedPosition = -1;

    private class ListViewHolder {

        //레이아웃
        public LinearLayout layout;

        //결제시각
        public TextView txtPaymentDate;

        //메뉴명
        public TextView txtOrderMenu;

        //결제가격
        public TextView txtPaymentPrice;

        //좌석번호
        public TextView txtSeatNo;
    }

    public PaymentInfoListAdapter(Context context, ArrayList<OrderInfo> arrays){

        this.mContext = context;
        this.inflater = LayoutInflater.from(context);
        this.mArrayList = arrays;
    }

    @Override
    public int getCount() {
        return mArrayList.size();
    }

    @Override
    public OrderInfo getItem(int position) {
        return mArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public void setSelectedIndex(int index) {
        mSelectedPosition = index;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = convertView;

        if(v == null){
            viewHolder = new ListViewHolder();
            v = inflater.inflate(R.layout.listview_item_payment, null);

            viewHolder.layout = v.findViewById(R.id.item_layout);
            viewHolder.txtPaymentDate= v.findViewById(R.id.item_txt_payment_date);
            viewHolder.txtOrderMenu = v.findViewById(R.id.item_txt_order_menu);
            viewHolder.txtPaymentPrice = v.findViewById(R.id.item_txt_payment_price);
            viewHolder.txtSeatNo = v.findViewById(R.id.item_txt_seat_no);

            v.setTag(viewHolder);

        }else {
            viewHolder = (ListViewHolder)v.getTag();
        }

        if(mSelectedPosition == position)
        {
            viewHolder.layout.setBackgroundColor(Color.YELLOW);
        }
        else
        {
            viewHolder.layout.setBackgroundColor(Color.WHITE);
        }

        viewHolder.layout.setTag(position);

        viewHolder.txtPaymentDate.setTag(position);
        viewHolder.txtPaymentDate.setText(getItem(position).getPAYMENT_DATE());

        viewHolder.txtOrderMenu.setTag(position);
        viewHolder.txtOrderMenu.setText(getItem(position).getORDER_MENU());

        viewHolder.txtPaymentPrice.setTag(position);
        viewHolder.txtPaymentPrice.setText(getItem(position).getORDER_PRICE());

        viewHolder.txtSeatNo.setTag(position);
        viewHolder.txtSeatNo.setText(getItem(position).getSEAT_NO());

        return v;
    }
}
