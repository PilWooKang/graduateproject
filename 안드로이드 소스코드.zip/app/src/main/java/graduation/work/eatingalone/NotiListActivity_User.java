package graduation.work.eatingalone;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

public class NotiListActivity_User extends Activity implements View.OnClickListener {

    public static String TAG = "NotiListActivity_User";

    private ListView listView;
    //private Button btnSelect;
    //private boolean bActivityRunning = true;
    private ProgressDialog mProgressDialog = null;

    private ArrayList<NotiInfo> mNotiInfoArrayList = new ArrayList<>();
    private NotiListAdapter mListAdapter = null;
    private NotiInfo mSelItem = null;

    /**
     * Firebase DB
     */
    private FirebaseDatabase mDatabase = null;
    private DatabaseReference mRefNotiInfo = null;
    private DataSnapshot mSnapNotiInfo = null;
    private String mMenu = "", mPrice = "";

    private QueryFirebaseThread queryThread = null;

    /**
     *  Firebase DB 최초 데이터 유무
     */
    private boolean isInitFirebase = true;

    /**
     *  Firebase DB Changed 유무
     */
    private boolean isChangedFirebase = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noti_list_user);

        listView = findViewById(R.id.anlu_listview);
        listView.setOnItemClickListener(new ListViewItemClickListener());
        listView.requestFocusFromTouch();

        /*
        btnSelect = findViewById(R.id.anlu_btn_select);
        btnSelect.setOnClickListener(this);
        */

        // Write a message to the database
        mDatabase = FirebaseDatabase.getInstance();

        mRefNotiInfo = mDatabase.getReference(Define.FB_NOTI_INFO);
        // Read from the database
        mRefNotiInfo.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                mSnapNotiInfo = dataSnapshot;
                isChangedFirebase = true;

                if(isInitFirebase == true) {
                    queryThread = new QueryFirebaseThread();
                    queryThread.setDaemon(true);
                    queryThread.start();
                    isInitFirebase = false;
                    isChangedFirebase = false;
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();  // Always call the superclass method first

        if(isChangedFirebase == true) {
            queryThread = new QueryFirebaseThread();
            queryThread.setDaemon(true);
            queryThread.start();
            isChangedFirebase = false;
        }
    }

    @Override
    public void onPause() {
        super.onPause();  // Always call the superclass method first

        //bActivityRunning = false;

        if(mProgressDialog != null)
        {
            mProgressDialog.dismiss();
            mProgressDialog = null;
        }
    }

    class QueryFirebaseThread extends Thread {

        public void run() {

            queryFirebase();
        }
    }

    private void queryFirebase() {

        mNotiInfoArrayList = new ArrayList<>();

        runOnUiThread(new Runnable()
        {
            public void run()
            {
                if(mSnapNotiInfo.getChildrenCount() == 0)
                {
                    if(mProgressDialog != null)
                    {
                        mProgressDialog.dismiss();
                        mProgressDialog = null;
                    }
                    Toast.makeText(NotiListActivity_User.this, "공지사항이 존재하지 않습니다.", Toast.LENGTH_SHORT).show();
                    mListAdapter = new NotiListAdapter(NotiListActivity_User.this, mNotiInfoArrayList);
                    listView.setAdapter(mListAdapter);
                    mListAdapter.notifyDataSetChanged();
                    return;
                }
                else {
                    mProgressDialog = new ProgressDialog(NotiListActivity_User.this);
                    mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                    mProgressDialog.setMessage("공지사항 업데이트중...\n잠시만 기다려 주십시오.");
                    mProgressDialog.setCanceledOnTouchOutside(false);
                    //mProgressDialog.setMax((int) mSnapMenuInfo.getChildrenCount());
                    mProgressDialog.show();
                }
            }
        });

        for (DataSnapshot child : mSnapNotiInfo.getChildren()) {

            String FBkey = "", FBTitle = "", FBContents = "", FBDate = "";
            FBkey = child.getKey();

            JSONObject jsonObj = new JSONObject((Map)child.getValue());
            if(jsonObj == null)
                continue;

            try {
                FBTitle = (String) jsonObj.get(Define.FB_NOTI_TITLE);
                FBContents = (String) jsonObj.get(Define.FB_NOTI_CONTENTS);
                FBDate = (String) jsonObj.get(Define.FB_NOTI_DATE);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            NotiInfo item = new NotiInfo();
            item.setINDEX_KEY(FBkey);
            item.setNOTI_TITLE(FBTitle);
            item.setNOTI_CONTENTS(FBContents);
            item.setNOTI_DATE(FBDate);
            mNotiInfoArrayList.add(item);
        }

        runOnUiThread(new Runnable() {
            public void run() {
                if (mProgressDialog != null) {
                    mProgressDialog.dismiss();
                    mProgressDialog = null;
                }

                /**
                 * 순서 변경(최신순)
                 */
                Collections.reverse(mNotiInfoArrayList);
                mListAdapter = new NotiListAdapter(NotiListActivity_User.this, mNotiInfoArrayList);
                listView.setAdapter(mListAdapter);
                mListAdapter.notifyDataSetChanged();
            }
        });
    }

    private class ListViewItemClickListener implements AdapterView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            mListAdapter.setSelectedIndex(position);
            mListAdapter.notifyDataSetChanged();
            mSelItem = (NotiInfo) parent.getItemAtPosition(position);

            Intent intent = new Intent(NotiListActivity_User.this, NotiActivity_Detail.class);
            intent.putExtra(Define.INTENT_NOTI_TITLE, mSelItem.getNOTI_TITLE());
            intent.putExtra(Define.INTENT_NOTI_CONTENTS, mSelItem.getNOTI_CONTENTS());
            intent.putExtra(Define.INTENT_NOTI_DATE, mSelItem.getNOTI_DATE());
            startActivity(intent);
        }
    }

    @Override
    public void onClick(View v) {

        Intent intent = null;

        switch (v.getId())
        {
            /*
            case R.id.anlu_btn_select:
                intent = new Intent(this, NotiAddActivity_Admin.class);
                startActivity(intent);
                break;
                */
        }
    }
}
