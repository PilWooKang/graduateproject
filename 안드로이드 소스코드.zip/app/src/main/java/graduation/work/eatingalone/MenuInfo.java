package graduation.work.eatingalone;

public class MenuInfo {

    //메뉴 인덱스(키값)
    private String m_INDEX_KEY;

    //메뉴명
    private String m_MENU_NAME;

    //메뉴 가격
    private String m_MENU_PRICE;

    //다운로드 이미지경로
    private String m_IMAGE_URL;

    //이미지 비트맵
    private android.graphics.Bitmap m_BITMAP;

    public void setINDEX_KEY(String INDEX_KEY)
    {
        this.m_INDEX_KEY = INDEX_KEY;
    }
    public void setMENU_NAME(String MENU_NAME)
    {
        this.m_MENU_NAME = MENU_NAME;
    }
    public void setMENU_PRICE(String MENU_PRICE)
    {
        this.m_MENU_PRICE = MENU_PRICE;
    }
    public void setIMAGE_URL(String IMAGE_URL) {
        this.m_IMAGE_URL = IMAGE_URL;
    }
    public void setBITMAP(android.graphics.Bitmap BITMAP) {
        this.m_BITMAP = BITMAP;
    }

    public String getINDEX_KEY(){
        return m_INDEX_KEY;
    }
    public String getMENU_NAME(){
        return m_MENU_NAME;
    }
    public String getMENU_PRICE(){
        return m_MENU_PRICE;
    }
    public String getIMAGE_URL(){
        return m_IMAGE_URL;
    }
    public android.graphics.Bitmap getBITMAP(){
        return m_BITMAP;
    }
}
