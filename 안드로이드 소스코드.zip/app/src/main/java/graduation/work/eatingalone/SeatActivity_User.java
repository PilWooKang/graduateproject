package graduation.work.eatingalone;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.nfc.NdefMessage;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Map;

public class SeatActivity_User extends Activity implements View.OnClickListener {

    public static String TAG = "SeatActivity_User";

    public static final String ERROR_DETECTED = "No NFC tag detected!";
    public static final String WRITE_SUCCESS = "Text written to the NFC tag successfully!";
    public static final String WRITE_ERROR = "Error during writing, is the NFC tag close enough to your device?";

    private Button btn_A, btn_B, btn_C, btn_D, btn_E, btn_F, btn_G, btn_H, btn_I, btn_J, btn_K, btn_L, btnSelect;

    private NfcAdapter nfcAdapter;
    private PendingIntent pendingIntent;
    private IntentFilter writeTagFilters[];
    private Tag myTag;
    private String tagText = "";
    boolean bSeatSelect = false;

    /**
     * Firebase 좌석 정보
     */
    private FirebaseDatabase mDatabase = null;
    private DatabaseReference mRefOrderInfo = null;
    private DataSnapshot mSnapOrderInfo = null;

    private ArrayList<String> mSeatInfoArrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seat_user);

        btn_A = findViewById(R.id.asu_btn_a);
        btn_A.setTag("0");
        btn_A.setOnClickListener(this);

        btn_B = findViewById(R.id.asu_btn_b);
        btn_B.setTag("0");
        btn_B.setOnClickListener(this);

        btn_C = findViewById(R.id.asu_btn_c);
        btn_C.setTag("0");
        btn_C.setOnClickListener(this);

        btn_D = findViewById(R.id.asu_btn_d);
        btn_D.setTag("0");
        btn_D.setOnClickListener(this);

        btn_E = findViewById(R.id.asu_btn_e);
        btn_E.setTag("0");
        btn_E.setOnClickListener(this);

        btn_F = findViewById(R.id.asu_btn_f);
        btn_F.setTag("0");
        btn_F.setOnClickListener(this);

        btn_G = findViewById(R.id.asu_btn_g);
        btn_G.setTag("0");
        btn_G.setOnClickListener(this);

        btn_H = findViewById(R.id.asu_btn_h);
        btn_H.setTag("0");
        btn_H.setOnClickListener(this);

        btn_I = findViewById(R.id.asu_btn_i);
        btn_I.setTag("0");
        btn_I.setOnClickListener(this);

        btn_J = findViewById(R.id.asu_btn_j);
        btn_J.setTag("0");
        btn_J.setOnClickListener(this);

        btn_K = findViewById(R.id.asu_btn_k);
        btn_K.setTag("0");
        btn_K.setOnClickListener(this);

        btn_L = findViewById(R.id.asu_btn_l);
        btn_L.setTag("0");
        btn_L.setOnClickListener(this);

        btnSelect = findViewById(R.id.asu_btn_select);
        btnSelect.setOnClickListener(this);

        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter == null) {
            // Stop here, we definitely need NFC
            Toast.makeText(this, "This device doesn't support NFC.", Toast.LENGTH_LONG).show();
            finish();
        }
        readFromIntent(getIntent());

        pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
        IntentFilter tagDetected = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
        tagDetected.addCategory(Intent.CATEGORY_DEFAULT);
        writeTagFilters = new IntentFilter[] { tagDetected };

        // Write a message to the database
        mDatabase = FirebaseDatabase.getInstance();
        mRefOrderInfo = mDatabase.getReference(Define.FB_ORDER_INFO);/*.child(Define.PHONE_NUM);*/

        // Read from the database
        mRefOrderInfo.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                mSnapOrderInfo = dataSnapshot;

                mSeatInfoArrayList = new ArrayList<>();
                String FBUserId = "", FBUserName = "", FBSeatNo = "", FBOrderMenu = "", FBOrderDate = "", FBPaymentComplete = "";

                for (DataSnapshot child : mSnapOrderInfo.getChildren()) {

                    String key = "";
                    key = child.getKey();

                    JSONObject jsonObj = new JSONObject((Map)child.getValue());
                    if(jsonObj == null)
                        continue;

                    try {
                        FBUserId = (String) jsonObj.get(Define.FB_ID);
                        FBUserName = (String) jsonObj.get(Define.FB_NAME);
                        FBSeatNo = (String) jsonObj.get(Define.FB_ORDER_SEAT_NO);
                        FBOrderMenu = (String) jsonObj.get(Define.FB_ORDER_MENU);
                        FBOrderDate = (String) jsonObj.get(Define.FB_ORDER_DATE);
                        FBPaymentComplete = (String) jsonObj.get(Define.FB_PAYMENT_COMPLETE);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if(FBPaymentComplete.equals("FALSE") == true)
                    {
                        mSeatInfoArrayList.add(FBSeatNo);

                        if(FBSeatNo.equals(Define.SEAT_A))
                            btn_A.setBackgroundColor(Color.RED);
                        if(FBSeatNo.equals(Define.SEAT_B))
                            btn_B.setBackgroundColor(Color.RED);
                        if(FBSeatNo.equals(Define.SEAT_C))
                            btn_C.setBackgroundColor(Color.RED);
                        if(FBSeatNo.equals(Define.SEAT_D))
                            btn_D.setBackgroundColor(Color.RED);
                        if(FBSeatNo.equals(Define.SEAT_E))
                            btn_E.setBackgroundColor(Color.RED);
                        if(FBSeatNo.equals(Define.SEAT_F))
                            btn_F.setBackgroundColor(Color.RED);
                        if(FBSeatNo.equals(Define.SEAT_G))
                            btn_G.setBackgroundColor(Color.RED);
                        if(FBSeatNo.equals(Define.SEAT_H))
                            btn_H.setBackgroundColor(Color.RED);
                        if(FBSeatNo.equals(Define.SEAT_I))
                            btn_I.setBackgroundColor(Color.RED);
                        if(FBSeatNo.equals(Define.SEAT_J))
                            btn_J.setBackgroundColor(Color.RED);
                        if(FBSeatNo.equals(Define.SEAT_K))
                            btn_K.setBackgroundColor(Color.RED);
                        if(FBSeatNo.equals(Define.SEAT_L))
                            btn_L.setBackgroundColor(Color.RED);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });

        Toast.makeText(this, "식사를 하실 좌석을 선택해주세요.", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        setIntent(intent);
        readFromIntent(intent);
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getAction())){
            myTag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        }
    }

    @Override
    public void onResume(){
        super.onResume();
        nfcAdapter.enableForegroundDispatch(this, pendingIntent, writeTagFilters, null);
    }

    @Override
    public void onPause(){
        super.onPause();
        nfcAdapter.disableForegroundDispatch(this);
    }

    /******************************************************************************
     **********************************Read From NFC Tag***************************
     ******************************************************************************/
    private void readFromIntent(Intent intent) {
        String action = intent.getAction();
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(action)
                || NfcAdapter.ACTION_TECH_DISCOVERED.equals(action)
                || NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action)) {
            Parcelable[] rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
            NdefMessage[] msgs = null;
            if (rawMsgs != null) {
                msgs = new NdefMessage[rawMsgs.length];
                for (int i = 0; i < rawMsgs.length; i++) {
                    msgs[i] = (NdefMessage) rawMsgs[i];
                }
            }
            buildTagViews(msgs);
        }
    }

    private void buildTagViews(NdefMessage[] msgs)
    {
        if (msgs == null || msgs.length == 0)
            return;

//        String tagId = new String(msgs[0].getRecords()[0].getType());
        byte[] payload = msgs[0].getRecords()[0].getPayload();
        String textEncoding = ((payload[0] & 128) == 0) ? "UTF-8" : "UTF-16"; // Get the Text Encoding
        int languageCodeLength = payload[0] & 0063; // Get the Language Code, e.g. "en"
        // String languageCode = new String(payload, 1, languageCodeLength, "US-ASCII");

        try {
            // Get the Text
            tagText = new String(payload, languageCodeLength + 1, payload.length - languageCodeLength - 1, textEncoding);
        } catch (UnsupportedEncodingException e) {
            Log.e("UnsupportedEncoding", e.toString());
        }

        /**
         * 주문내역에 해당 좌석이 있는지 검색한다.
         */
        for(String seat : mSeatInfoArrayList)
        {
            /**
             * 이미 좌석이 찼을경우
             */
            if(seat.equals(tagText))
            {
                Toast.makeText(this, "해당좌석은 이미 식사중입니다.\n다른 좌석을 선택해 주세요!", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        if(tagText.equals(Define.SEAT_A))
        {
            bSeatSelect = true;
            btn_A.setTag("1");
            btn_A.setBackgroundColor(Color.RED);
            Toast.makeText(this, "A좌석 선택 완료!", Toast.LENGTH_SHORT).show();
        }
        else if(tagText.equals(Define.SEAT_B))
        {
            bSeatSelect = true;
            btn_B.setTag("1");
            btn_B.setBackgroundColor(Color.RED);
            Toast.makeText(this, "B좌석 선택 완료!", Toast.LENGTH_SHORT).show();
        }
        else if(tagText.equals(Define.SEAT_C))
        {
            bSeatSelect = true;
            btn_C.setTag("1");
            btn_C.setBackgroundColor(Color.RED);
            Toast.makeText(this, "C좌석 선택 완료!", Toast.LENGTH_SHORT).show();
        }
        else if(tagText.equals(Define.SEAT_D))
        {
            bSeatSelect = true;
            btn_D.setTag("1");
            btn_D.setBackgroundColor(Color.RED);
            Toast.makeText(this, "D좌석 선택 완료!", Toast.LENGTH_SHORT).show();
        }
        else if(tagText.equals(Define.SEAT_E))
        {
            bSeatSelect = true;
            btn_E.setTag("1");
            btn_E.setBackgroundColor(Color.RED);
            Toast.makeText(this, "E좌석 선택 완료!", Toast.LENGTH_SHORT).show();
        }
        else if(tagText.equals(Define.SEAT_F))
        {
            bSeatSelect = true;
            btn_F.setTag("1");
            btn_F.setBackgroundColor(Color.RED);
            Toast.makeText(this, "F좌석 선택 완료!", Toast.LENGTH_SHORT).show();
        }
        else if(tagText.equals(Define.SEAT_G))
        {
            bSeatSelect = true;
            btn_G.setTag("1");
            btn_G.setBackgroundColor(Color.RED);
            Toast.makeText(this, "G좌석 선택 완료!", Toast.LENGTH_SHORT).show();
        }
        else if(tagText.equals(Define.SEAT_H))
        {
            bSeatSelect = true;
            btn_H.setTag("1");
            btn_H.setBackgroundColor(Color.RED);
            Toast.makeText(this, "H좌석 선택 완료!", Toast.LENGTH_SHORT).show();
        }
        else if(tagText.equals(Define.SEAT_I))
        {
            bSeatSelect = true;
            btn_I.setTag("1");
            btn_I.setBackgroundColor(Color.RED);
            Toast.makeText(this, "I좌석 선택 완료!", Toast.LENGTH_SHORT).show();
        }
        else if(tagText.equals(Define.SEAT_J))
        {
            bSeatSelect = true;
            btn_J.setTag("1");
            btn_J.setBackgroundColor(Color.RED);
            Toast.makeText(this, "J좌석 선택 완료!", Toast.LENGTH_SHORT).show();
        }
        else if(tagText.equals(Define.SEAT_K))
        {
            bSeatSelect = true;
            btn_K.setTag("1");
            btn_K.setBackgroundColor(Color.RED);
            Toast.makeText(this, "K좌석 선택 완료!", Toast.LENGTH_SHORT).show();
        }
        else if(tagText.equals(Define.SEAT_L))
        {
            bSeatSelect = true;
            btn_L.setTag("1");
            btn_L.setBackgroundColor(Color.RED);
            Toast.makeText(this, "L좌석 선택 완료!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onClick(View v) {

        Intent intent = null;

        switch (v.getId())
        {
            case R.id.asu_btn_select:
                if(bSeatSelect == false)
                {
                    Toast.makeText(this, "좌석 앞에 놓인 NFC Tag에 스마트폰을 접촉해 주시기 바랍니다.", Toast.LENGTH_SHORT).show();
                    return;
                }
                intent = new Intent(this, MenuListActivity_User.class);
                intent.putExtra(Define.INTENT_SEAT_NO, tagText);
                startActivity(intent);
                finish();
                break;

            case R.id.asu_btn_a:
                break;
            case R.id.asu_btn_b:
                break;
            case R.id.asu_btn_c:
                break;
            case R.id.asu_btn_d:
                break;
            case R.id.asu_btn_e:
                break;
            case R.id.asu_btn_f:
                break;
            case R.id.asu_btn_g:
                break;
            case R.id.asu_btn_h:
                break;
            case R.id.asu_btn_i:
                break;
            case R.id.asu_btn_j:
                break;
            case R.id.asu_btn_k:
                break;
            case R.id.asu_btn_l:
                break;
        }
    }
}
