package graduation.work.eatingalone;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

public class MenuListActivity_Admin extends Activity implements View.OnClickListener {

    public static String TAG = "MenuListActivity_Admin";

    private ListView listView;
    private Button btnAdd;
    //private boolean bActivityRunning = true;
    private ProgressDialog mProgressDialog = null;

    private ArrayList<MenuInfo> mMenuArrayList = new ArrayList<>();
    private MenuListAdapter mListAdapter = null;
    private MenuInfo mSelItem = null;

    /**
     * Firebase DB
     */
    private FirebaseDatabase mDatabase = null;
    private DatabaseReference mRefMenuInfo = null;
    private DataSnapshot mSnapMenuInfo = null;
    private String mMenu = "", mPrice = "";

    private QueryFirebaseThread queryThread = null;

    /**
     *  Firebase DB 최초 데이터 유무
     */
    private boolean isInitFirebase = true;

    /**
     *  Firebase DB Changed 유무
     */
    private boolean isChangedFirebase = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_list_admin);

        listView = findViewById(R.id.amla_listview);
        listView.setOnItemClickListener(new ListViewItemClickListener());
        listView.requestFocusFromTouch();

        btnAdd = findViewById(R.id.amla_btn_add);
        btnAdd.setOnClickListener(this);

        // Write a message to the database
        mDatabase = FirebaseDatabase.getInstance();

        mRefMenuInfo = mDatabase.getReference(Define.FB_MENU_INFO);
        // Read from the database
        mRefMenuInfo.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                mSnapMenuInfo = dataSnapshot;
                isChangedFirebase = true;

                if(isInitFirebase == true) {
                    queryThread = new QueryFirebaseThread();
                    queryThread.setDaemon(true);
                    queryThread.start();
                    isInitFirebase = false;
                    isChangedFirebase = false;
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();  // Always call the superclass method first

        if(isChangedFirebase == true) {
            queryThread = new QueryFirebaseThread();
            queryThread.setDaemon(true);
            queryThread.start();
            isChangedFirebase = false;
        }
    }

    @Override
    public void onPause() {
        super.onPause();  // Always call the superclass method first

        //bActivityRunning = false;

        if(mProgressDialog != null)
        {
            mProgressDialog.dismiss();
            mProgressDialog = null;
        }
    }

    class QueryFirebaseThread extends Thread {

        public void run() {

            queryFirebase();
        }
    }

    private void queryFirebase() {

        mMenuArrayList = new ArrayList<>();

        runOnUiThread(new Runnable()
        {
            public void run()
            {
                if(mSnapMenuInfo.getChildrenCount() == 0)
                {
                    if(mProgressDialog != null)
                    {
                        mProgressDialog.dismiss();
                        mProgressDialog = null;
                    }
                    Toast.makeText(MenuListActivity_Admin.this, "메뉴가 존재하지 않습니다.\n메뉴를 추가해주세요.", Toast.LENGTH_SHORT).show();
                    mListAdapter = new MenuListAdapter(MenuListActivity_Admin.this, mMenuArrayList);
                    listView.setAdapter(mListAdapter);
                    mListAdapter.notifyDataSetChanged();
                    return;
                }
                else {
                    mProgressDialog = new ProgressDialog(MenuListActivity_Admin.this);
                    mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                    mProgressDialog.setMessage("메뉴리스트 업데이트중...\n잠시만 기다려 주십시오.");
                    mProgressDialog.setCanceledOnTouchOutside(false);
                    //mProgressDialog.setMax((int) mSnapMenuInfo.getChildrenCount());
                    mProgressDialog.show();
                }
            }
        });

        for (DataSnapshot child : mSnapMenuInfo.getChildren()) {

            String FBkey = "", FBMenu = "", FBPrice = "", FBImgUrl = "";
            FBkey = child.getKey();

            JSONObject jsonObj = new JSONObject((Map)child.getValue());
            if(jsonObj == null)
                continue;

            try {
                FBMenu = (String) jsonObj.get(Define.FB_MENU);
                FBPrice = (String) jsonObj.get(Define.FB_PRICE);
                FBImgUrl = (String) jsonObj.get(Define.FB_MENU_IMG_URL);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            MenuInfo item = new MenuInfo();
            item.setINDEX_KEY(FBkey);
            item.setMENU_NAME(FBMenu);
            item.setMENU_PRICE(FBPrice);
            item.setIMAGE_URL(FBImgUrl);
            Bitmap bitmap = getBitmapFromURL(FBImgUrl);
            item.setBITMAP(bitmap);
            mMenuArrayList.add(item);
        }

        runOnUiThread(new Runnable() {
            public void run() {
                if (mProgressDialog != null) {
                    mProgressDialog.dismiss();
                    mProgressDialog = null;
                }

                /**
                 * 순서 변경(최신순)
                 */
                //Collections.reverse(mMenuArrayList);
                mListAdapter = new MenuListAdapter(MenuListActivity_Admin.this, mMenuArrayList);
                listView.setAdapter(mListAdapter);
                mListAdapter.notifyDataSetChanged();
            }
        });
    }

    /**
     * URL 주소로 Bitmap 변환 함수
     * @param imgUrl
     * @return
     */
    public Bitmap getBitmapFromURL(String imgUrl)
    {
        HttpURLConnection connection = null;
        try
        {
            URL url = new URL(imgUrl);
            connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e)
        {
            e.printStackTrace();
            return null;
        }
        finally
        {
            if(connection!=null)
                connection.disconnect();
        }
    }

    private class ListViewItemClickListener implements AdapterView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            mListAdapter.setSelectedIndex(position);
            mListAdapter.notifyDataSetChanged();
            mSelItem = (MenuInfo) parent.getItemAtPosition(position);

            Intent intent = new Intent(MenuListActivity_Admin.this, MenuModifyActivity_Admin.class);
            intent.putExtra(Define.INTENT_MENU_INDEX_KEY, mSelItem.getINDEX_KEY());
            intent.putExtra(Define.INTENT_MENU_NAME, mSelItem.getMENU_NAME());
            intent.putExtra(Define.INTENT_MENU_PRICE, mSelItem.getMENU_PRICE());
            intent.putExtra(Define.INTENT_MENU_IMG_URL, mSelItem.getIMAGE_URL());
            startActivity(intent);
        }
    }

    @Override
    public void onClick(View v) {

        Intent intent = null;

        switch (v.getId())
        {
            case R.id.amla_btn_add:
                intent = new Intent(this, MenuAddActivity_Admin.class);
                startActivity(intent);
                break;
        }
    }
}
