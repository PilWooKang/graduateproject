package graduation.work.eatingalone;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

public class LoginActivity extends Activity implements View.OnClickListener{

    public static String TAG = "LoginActivity";

    private EditText edtId, edtPw;
    private Button btnLogin, btnJoin;

    /**
     * FiraBase DB
     */
    private FirebaseDatabase mDatabase = null;
    private DatabaseReference mRefMemberInfo;
    private DataSnapshot mSnapMemberInfo = null;

    private long pressedTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edtId = findViewById(R.id.al_edt_id);
        edtId.setText("admin");
        edtPw = findViewById(R.id.al_edt_pw);
        edtPw.setText("admin");

        btnLogin = findViewById(R.id.al_btn_login);
        btnLogin.setOnClickListener(this);

        btnJoin = findViewById(R.id.al_btn_join);
        btnJoin.setOnClickListener(this);

        if (checkFilePermission()) {
            TelephonyManager TM = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
            Define.USER_PHONE = TM.getLine1Number();
            String Kor_Internal_Number = "+82";
            String prefix_Num = null;
            if (Define.USER_PHONE != null) {
                prefix_Num = Define.USER_PHONE.substring(0, 3);

                if (Kor_Internal_Number.equalsIgnoreCase(prefix_Num) == true) {
                    Define.USER_PHONE = "0" + Define.USER_PHONE.substring(3);/*+82xxx*/
                }
            }

            // Write a message to the database
            mDatabase = FirebaseDatabase.getInstance();
            mRefMemberInfo = mDatabase.getReference(Define.FB_MEMBER_INFO);

            // Read from the database
            mRefMemberInfo.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    // This method is called once with the initial value and again
                    // whenever data at this location is updated.

                    mSnapMemberInfo = dataSnapshot;
                }

                @Override
                public void onCancelled(DatabaseError error) {
                    // Failed to read value
                    Log.w(TAG, "Failed to read value.", error.toException());
                }
            });

        } else {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.RECEIVE_SMS
            }, Define.MY_PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onBackPressed() {
        if ( pressedTime == 0 ) {
            Toast.makeText(LoginActivity.this, " 한 번 더 누르면 종료됩니다." , Toast.LENGTH_SHORT).show();
            pressedTime = System.currentTimeMillis();
        }
        else {
            int seconds = (int) (System.currentTimeMillis() - pressedTime);

            if ( seconds > 2000 ) {
                Toast.makeText(LoginActivity.this, " 한 번 더 누르면 종료됩니다." , Toast.LENGTH_SHORT).show();
                pressedTime = 0 ;
            }
            else {
                // app 종료 시키기
                super.onBackPressed();
            }
        }
    }

    private boolean checkFilePermission() {
        int result1 = ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.READ_PHONE_STATE);
        int result2 = ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.SEND_SMS);
        int result3 = ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.RECEIVE_SMS);

        if (result1 != 0 || result2 != 0 || result3 != 0)
            return false;

        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case Define.MY_PERMISSION_REQUEST_CODE: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 2 &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED &&
                        grantResults[1] == PackageManager.PERMISSION_GRANTED &&
                        grantResults[2] == PackageManager.PERMISSION_GRANTED
                        ) {

                    TelephonyManager TM = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                        // TODO: Consider calling
                        //    ActivityCompat#requestPermissions
                        // here to request the missing permissions, and then overriding
                        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                        //                                          int[] grantResults)
                        // to handle the case where the user grants the permission. See the documentation
                        // for ActivityCompat#requestPermissions for more details.
                        return;
                    }
                    Define.USER_PHONE = TM.getLine1Number();
                    String Kor_Internal_Number = "+82";
                    String prefix_Num = null;
                    if ( Define.USER_PHONE != null ) {
                        prefix_Num = Define.USER_PHONE.substring(0, 3);

                        if ( Kor_Internal_Number.equalsIgnoreCase(prefix_Num) == true ) {
                            Define.USER_PHONE = "0" + Define.USER_PHONE.substring(3);/*+82xxx*/
                        }
                    }

                    // Write a message to the database
                    mDatabase = FirebaseDatabase.getInstance();
                    mRefMemberInfo = mDatabase.getReference(Define.FB_MEMBER_INFO);

                    // Read from the database
                    mRefMemberInfo.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            // This method is called once with the initial value and again
                            // whenever data at this location is updated.

                            mSnapMemberInfo = dataSnapshot;
                        }

                        @Override
                        public void onCancelled(DatabaseError error) {
                            // Failed to read value
                            Log.w(TAG, "Failed to read value.", error.toException());
                        }
                    });

                } else {

                    finish();
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    @Override
    public void onClick(View view) {

        Intent intent = null;

        switch (view.getId())
        {
            case R.id.al_btn_login:

                String loginId = edtId.getText().toString();
                String loginPw = edtPw.getText().toString();
                String keyId = "";

                boolean matchedMember = false;

                if(mSnapMemberInfo == null)
                {
                    Toast.makeText(this, "Firebase 정보 동기화중...", Toast.LENGTH_SHORT).show();
                    return;
                }

                for (DataSnapshot child : mSnapMemberInfo.getChildren()) {

                    String key = "";
                    key = child.getKey();

                    JSONObject jsonObj = new JSONObject((Map) child.getValue());
                    if (jsonObj == null)
                        continue;

                    try {
                        String FB_Name = (String) jsonObj.get(Define.FB_NAME);
                        String FB_Phone = (String) jsonObj.get(Define.FB_PHONE);
                        String FB_Id = (String) jsonObj.get(Define.FB_ID);
                        String FB_Pw = (String) jsonObj.get(Define.FB_PW);
                        String FB_Sex = (String) jsonObj.get(Define.FB_SEX);

                        /**
                         * 입력한 ID와 PW가 Firebase에 저장된 정보와 일치할 경우
                         */
                        if(loginId.equals(FB_Id) && loginPw.equals(FB_Pw))
                        {
                            Define.USER_NAME = FB_Name;
                            Define.USER_PHONE = FB_Phone;
                            Define.USER_ID = FB_Id;
                            Define.USER_SEX = FB_Id;
                            matchedMember = true;
                            break;
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                if(matchedMember == false)
                {
                    Toast.makeText(this, "아이디와 비밀번호를 다시 확인해주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }

                btnLogin.setBackgroundResource(R.drawable.layout_solid_border_red);

                if(loginId.equals("admin")) {
                    Define.IS_ADMIN = "TRUE";
                    intent = new Intent(this, MainActivity_Admin.class);
                }
                else
                    intent = new Intent(this, MainActivity_User.class);

                startActivity(intent);
                finish();
                break;

            case R.id.al_btn_join:
                btnJoin.setBackgroundResource(R.drawable.layout_solid_border_red);
                intent = new Intent(this, JoinActivity.class);
                startActivity(intent);
                break;
        }
    }
}
