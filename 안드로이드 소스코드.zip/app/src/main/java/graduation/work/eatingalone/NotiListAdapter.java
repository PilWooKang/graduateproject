package graduation.work.eatingalone;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class NotiListAdapter extends BaseAdapter {

    private ArrayList<NotiInfo> mArrayList = null;
    private ListViewHolder viewHolder = null;
    private Context mContext = null;
    private LayoutInflater inflater = null;

    //리스트에서 선택한 Position
    private int mSelectedPosition = -1;

    private class ListViewHolder {

        //제목
        public TextView txtTitle;

        //날짜
        public TextView txtDate;
    }

    public NotiListAdapter(Context context, ArrayList<NotiInfo> arrays) {

        this.mContext = context;
        this.inflater = LayoutInflater.from(context);
        this.mArrayList = arrays;
    }

    @Override
    public int getCount() {
        return mArrayList.size();
    }

    @Override
    public NotiInfo getItem(int position) {
        return mArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public void setSelectedIndex(int index) {
        mSelectedPosition = index;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        View v = convertView;

        if (v == null) {
            viewHolder = new ListViewHolder();
            v = inflater.inflate(R.layout.listview_item_noti, null);

            viewHolder.txtTitle = v.findViewById(R.id.item_txt_noti_title);
            viewHolder.txtDate = v.findViewById(R.id.item_txt_noti_date);

            v.setTag(viewHolder);

        } else {
            viewHolder = (ListViewHolder) v.getTag();
        }

        if (mSelectedPosition == position) {
            viewHolder.txtTitle.setBackgroundColor(Color.parseColor("#eeeeee"));
            viewHolder.txtDate.setBackgroundColor(Color.parseColor("#eeeeee"));
        } else {
            viewHolder.txtTitle.setBackgroundColor(Color.parseColor("#ffffff"));
            viewHolder.txtDate.setBackgroundColor(Color.parseColor("#ffffff"));
        }

        viewHolder.txtTitle.setTag(position);
        viewHolder.txtTitle.setText(getItem(position).getNOTI_TITLE());

        viewHolder.txtDate.setTag(position);
        viewHolder.txtDate.setText(getItem(position).getNOTI_DATE());

        return v;
    }
}
