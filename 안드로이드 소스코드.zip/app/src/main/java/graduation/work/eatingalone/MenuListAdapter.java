package graduation.work.eatingalone;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MenuListAdapter extends BaseAdapter {

    private ArrayList<MenuInfo> mArrayList = null;
    private ListViewHolder viewHolder = null;
    private Context mContext = null;
    private LayoutInflater inflater = null;

    //리스트에서 선택한 Position
    private int mSelectedPosition = -1;

    private class ListViewHolder {

        //이미지
        public ImageView imageView;

        //메뉴명
        public TextView txtMenuName;

        //메뉴가격
        public TextView txtMenuPrice;
    }

    public MenuListAdapter(Context context, ArrayList<MenuInfo> arrays) {

        this.mContext = context;
        this.inflater = LayoutInflater.from(context);
        this.mArrayList = arrays;
    }

    @Override
    public int getCount() {
        return mArrayList.size();
    }

    @Override
    public MenuInfo getItem(int position) {
        return mArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    public void setSelectedIndex(int index) {
        mSelectedPosition = index;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        View v = convertView;

        if (v == null) {
            viewHolder = new ListViewHolder();
            v = inflater.inflate(R.layout.listview_item_menu, null);

            viewHolder.imageView = v.findViewById(R.id.item_imageview);
            viewHolder.txtMenuName = v.findViewById(R.id.item_txt_menu_name);
            viewHolder.txtMenuPrice = v.findViewById(R.id.item_txt_menu_price);

            v.setTag(viewHolder);

        } else {
            viewHolder = (ListViewHolder) v.getTag();
        }

        if (mSelectedPosition == position) {
            viewHolder.txtMenuName.setBackgroundColor(Color.parseColor("#eeeeee"));
            viewHolder.txtMenuPrice.setBackgroundColor(Color.parseColor("#eeeeee"));
        } else {
            viewHolder.txtMenuName.setBackgroundColor(Color.parseColor("#ffffff"));
            viewHolder.txtMenuPrice.setBackgroundColor(Color.parseColor("#ffffff"));
        }

        viewHolder.imageView.setTag(position);
        viewHolder.imageView.setImageBitmap(getItem(position).getBITMAP());

        viewHolder.txtMenuName.setTag(position);
        viewHolder.txtMenuName.setText(getItem(position).getMENU_NAME());

        viewHolder.txtMenuPrice.setTag(position);
        viewHolder.txtMenuPrice.setText(getItem(position).getMENU_PRICE());

        return v;
    }
}
