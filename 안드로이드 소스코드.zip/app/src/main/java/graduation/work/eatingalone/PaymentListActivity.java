package graduation.work.eatingalone;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

/**
 * 고객이 결제했던 모든내역 리스트
 */
public class PaymentListActivity extends Activity implements View.OnClickListener {

    public static String TAG = "PaymentListActivity";

    /**
     * Firebase DB
     */
    private FirebaseDatabase mDatabase = null;
    private DatabaseReference mRefOrderInfo = null;
    private DataSnapshot mSnapOrderInfo = null;

    private ListView listView;
    private ArrayList<OrderInfo> mPaymentInfoList = new ArrayList<>();
    private PaymentInfoListAdapter mListAdapter = null;
    private OrderInfo mSelItem = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_list);

        listView = findViewById(R.id.apl_listview);
        listView.setOnItemClickListener(new ListViewItemClickListener());
        listView.requestFocusFromTouch();

        // Write a message to the database
        mDatabase = FirebaseDatabase.getInstance();
        mRefOrderInfo = mDatabase.getReference(Define.FB_ORDER_INFO);/*.child(Define.PHONE_NUM);*/

        // Read from the database
        mRefOrderInfo.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                mSnapOrderInfo = dataSnapshot;
                mPaymentInfoList = new ArrayList<>();

                String FBKey = "", FBUserId = "", FBUserName = "", FBOrderMenu = "", FBOrderPrice = "", FBOrderDate = "", FBSeatNo = "", FBPaymentComplete = "", FBPaymentDate = "";

                for (DataSnapshot child : mSnapOrderInfo.getChildren()) {

                    FBKey = child.getKey();

                    JSONObject jsonObj = new JSONObject((Map)child.getValue());
                    if(jsonObj == null)
                        continue;

                    try {
                        FBUserId = (String) jsonObj.get(Define.FB_ID);
                        FBUserName = (String) jsonObj.get(Define.FB_NAME);
                        FBOrderMenu = (String) jsonObj.get(Define.FB_ORDER_MENU);
                        FBOrderPrice = (String) jsonObj.get(Define.FB_ORDER_PRICE);
                        FBOrderDate = (String) jsonObj.get(Define.FB_ORDER_DATE);
                        FBSeatNo = (String) jsonObj.get(Define.FB_ORDER_SEAT_NO);
                        FBPaymentComplete = (String) jsonObj.get(Define.FB_PAYMENT_COMPLETE);
                        FBPaymentDate = (String) jsonObj.get(Define.FB_PAYMENT_DATE);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    /**
                     * 결제가 완료된경우에만 결제내역 리스트에 추가한다.
                     */
                    if(FBPaymentComplete.equals("TRUE") == true)
                    {
                        OrderInfo item = new OrderInfo();
                        item.setINDEX_KEY(FBKey);
                        item.setUSER_NAME(FBUserName);
                        item.setORDER_MENU(FBOrderMenu);
                        item.setORDER_PRICE(FBOrderPrice);
                        item.setORDER_DATE(FBOrderDate);
                        item.setSEAT_NO(FBSeatNo);
                        item.setPAYMENT_DATE(FBPaymentDate);
                        item.setPAYMENT_COMPLETE(FBPaymentComplete);

                        mPaymentInfoList.add(item);
                    }
                }

                mListAdapter = new PaymentInfoListAdapter(PaymentListActivity.this, mPaymentInfoList);
                listView.setAdapter(mListAdapter);
                mListAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });

        mListAdapter = new PaymentInfoListAdapter(PaymentListActivity.this, mPaymentInfoList);
        listView.setAdapter(mListAdapter);
        mListAdapter.notifyDataSetChanged();
    }

    @Override
    public void onResume() {
        super.onResume();  // Always call the superclass method first

        if(mListAdapter != null)
        {
            mListAdapter.setSelectedIndex(-1);
            mListAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onPause() {
        super.onPause();  // Always call the superclass method first

    }

    private class ListViewItemClickListener implements AdapterView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Intent intent = null;

            mListAdapter.setSelectedIndex(position);
            mListAdapter.notifyDataSetChanged();
            mSelItem = (OrderInfo) parent.getItemAtPosition(position);

            intent = new Intent(PaymentListActivity.this, PaymentActivity_Admin.class);
            intent.putExtra(Define.INTENT_USER_NAME, mSelItem.getUSER_NAME());
            intent.putExtra(Define.INTENT_STORE_NAME, "혼밥남녀 1호점");
            intent.putExtra(Define.INTENT_PRODUCT_NAME, mSelItem.getORDER_MENU());
            intent.putExtra(Define.INTENT_CARD_NAME, "VISA Card");
            intent.putExtra(Define.INTENT_PAYMENT_PRICE, mSelItem.getORDER_PRICE());
            intent.putExtra(Define.INTENT_PAYMENT_DATE, mSelItem.getPAYMENT_DATE());
            startActivity(intent);
        }
    }

    @Override
    public void onClick(View view) {

        Intent intent = null;

        switch (view.getId()) {
        }
    }
}
