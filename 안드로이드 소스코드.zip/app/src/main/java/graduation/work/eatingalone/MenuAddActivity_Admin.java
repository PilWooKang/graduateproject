package graduation.work.eatingalone;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;

/**
 * 메뉴 추가
 */
public class MenuAddActivity_Admin extends Activity implements View.OnClickListener {

    public static String TAG = "MenuAddActivity_Admin";

    private EditText edtMenu, edtPrice;
    private ImageView imageView;
    private Button btnImgUpload, btnAdd;

    /**
     * Firebase DB
     */
    private FirebaseDatabase mDatabase = null;
    private DatabaseReference mRefMenuInfo = null;
    private DataSnapshot mSnapMenuInfo = null;
    private ArrayList<Integer> mMenuKeyList = new ArrayList<Integer>();
    private String strMenu = "", strPrice = "";

    /**
     * Firebase Storage
     */
    private StorageReference mStorage = null;
    private StorageReference mStorageMenuInfo = null;

    private Uri mImageUri = null;
    private ProgressDialog mProgressDialog = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_add);

        edtMenu = findViewById(R.id.ama_edt_menu);
        edtPrice = findViewById(R.id.ama_edt_price);

        /*
        edtPrice.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                // 입력되는 텍스트에 변화가 있을 때
            }

            @Override
            public void afterTextChanged(Editable arg0) {

                // 입력이 끝났을 때
                if(arg0.toString().equals("") == false)
                    nPrice = Integer.parseInt(arg0.toString());
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                // 입력하기 전에
            }
        });
        */
        imageView = findViewById(R.id.ama_imageview);

        btnImgUpload = findViewById(R.id.ama_btn_img_upload);
        btnImgUpload.setOnClickListener(this);

        btnAdd = findViewById(R.id.ama_btn_add);
        btnAdd.setOnClickListener(this);

        // Write a message to the database
        mDatabase = FirebaseDatabase.getInstance();

        mRefMenuInfo = mDatabase.getReference(Define.FB_MENU_INFO);
        // Read from the database
        mRefMenuInfo.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                mSnapMenuInfo = dataSnapshot;

                mMenuKeyList = new ArrayList<Integer>();
                for (DataSnapshot child : mSnapMenuInfo.getChildren()) {

                    String key = "";
                    key = child.getKey();
                    mMenuKeyList.add(Integer.parseInt(key));
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });

        mStorage = FirebaseStorage.getInstance().getReference();
        mStorageMenuInfo = mStorage.child(Define.FB_MENU_INFO);
    }

    /**
     * 숫자에 천단위마다 콤마 넣기
     * @return String
     * */
    public static String toNumFormat(int num) {
        DecimalFormat df = new DecimalFormat("#,###");
        return df.format(num);
    }

    /**
     * 앨범에서 이미지 가져오기
     */
    public void doTakeAlbumAction()
    {
        //앨범 호출
        Intent intent = new Intent(Intent.ACTION_PICK);

        intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        startActivityForResult(intent, Define.REQ_PICK_FROM_ALBUM);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK)
            return;

        switch (requestCode) {

            case Define.REQ_PICK_FROM_ALBUM: {
                //이후의 처리가 카메라와 같으므로 일단 break 없이 진행합니다.
                //실제 코드에서는 좀더 합리적인 방법을 선택하시기 바랍니다.
                mImageUri = data.getData();

                Bitmap bitmapOrg = null;
                try {
                    bitmapOrg = MediaStore.Images.Media.getBitmap(getContentResolver(), mImageUri);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                //배치해놓은 ImageView에 set
                if(bitmapOrg != null)
                    imageView.setImageBitmap(bitmapOrg);

                //bitmapOrg = MediaStore.Images.Media.getBitmap(getContentResolver(), urione);

                //이미지를 가져온 이후의 리사이즈할 이미지 크기를 결정합니다.
                //이후에 이미지 크롭 어플리케이션을 호출하게 됩니다.
                /*
                Intent intent = new Intent("com.android.camera.action.CROP");
                intent.setDataAndType(mImageUri, "image/*");

                //CROP할 이미지를 200*200 크기로 저장
                intent.putExtra("outputX", 500);    //CROP한 이미지의 X축 크기
                intent.putExtra("outputY", 500);    //CROP한 이미지의 X축 크기
                intent.putExtra("aspectX", 1);      //CROP 박스의 X축 비율
                intent.putExtra("aspectY", 1);      //CROP 박스의 Y축 비율
                intent.putExtra("scale", true);      //CROP 박스의 Y축 비율
                intent.putExtra("return-data", true);
                startActivityForResult(intent, Define.REQ_CROP_FROM_IMAGE);    //CROP_FROM_CAMERA case문 이동
                */
            }
            break;

            /*
            case Define.REQ_CROP_FROM_IMAGE: {

                //크롭이 된 이후의 이미지를 넘겨받는다.
                //이미지뷰에 이미지를 보여주거나 부가적인 작업 이후에
                //임시파일을 삭제한다.
                if ( resultCode != RESULT_OK )
                    return;

                final Bundle extras = data.getExtras();

                mImageUri = data.getData();

                if(mImageUri == null)
                    return;

                Bitmap bitmapOrg = null;
                try {
                    bitmapOrg = MediaStore.Images.Media.getBitmap(getContentResolver(), mImageUri);
                } catch (IOException e) {
                    e.printStackTrace();
                }

                //배치해놓은 ImageView에 set
                if(bitmapOrg != null)
                    imgView.setImageBitmap(bitmapOrg);
            }
            break;
            */
        }
    }

    @Override
    public void onClick(View v) {

        Intent intent = null;

        switch (v.getId())
        {
            case R.id.ama_btn_img_upload:
                doTakeAlbumAction();
                break;

            case R.id.ama_btn_add:

                strMenu = edtMenu.getText().toString();
                strPrice = edtPrice.getText().toString();

                if(mSnapMenuInfo == null)
                {
                    Toast.makeText(this, "Firebase 정보 동기화중", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(strMenu.equals(""))
                {
                    Toast.makeText(this, "메뉴명을 입력해 주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(strPrice.equals(""))
                {
                    Toast.makeText(this, "메뉴 가격을 입력해 주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (mImageUri == null) {
                    Toast.makeText(this, "이미지 파일을 업로드해주세요..", Toast.LENGTH_LONG).show();
                    return;
                }

                int nPrice = Integer.parseInt(strPrice);
                strPrice = toNumFormat(nPrice) + "원";

                mProgressDialog = new ProgressDialog(this);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.setMessage("메뉴 업로드중입니다.\n잠시만 기다려 주십시오.");
                mProgressDialog.setCancelable(false);
                mProgressDialog.setCanceledOnTouchOutside(false);
                mProgressDialog.show();

                int nKeyMax = 0;
                if(mMenuKeyList.size() > 0)
                    nKeyMax = (Collections.max(mMenuKeyList)).intValue();

                mStorageMenuInfo.child(Integer.toString(nKeyMax + 1)).putFile(mImageUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                // Get a URL to the uploaded content
                                //Uri downloadUrl = taskSnapshot.getDownloadUrl();
                                if(mProgressDialog != null)
                                {
                                    mProgressDialog.dismiss();
                                    mProgressDialog = null;

                                    int nKeyMax = 0;
                                    if (mMenuKeyList.size() > 0)
                                        nKeyMax = (Collections.max(mMenuKeyList)).intValue();

                                    mRefMenuInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_MENU).setValue(strMenu);
                                    mRefMenuInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_PRICE).setValue(strPrice);
                                    mRefMenuInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_MENU_IMG_URL).setValue(taskSnapshot.getDownloadUrl().toString());

                                    Toast.makeText(MenuAddActivity_Admin.this, "메뉴 추가 완료", Toast.LENGTH_SHORT).show();
                                    finish();
                                }
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // Handle unsuccessful uploads
                                if(mProgressDialog != null)
                                {
                                    mProgressDialog.dismiss();
                                    mProgressDialog = null;
                                    Toast.makeText(MenuAddActivity_Admin.this, "메뉴 추가 실패\n다시 시도해 주세요.", Toast.LENGTH_SHORT).show();
                                    //finish();
                                }
                            }
                        });

                break;
        }
    }
}
