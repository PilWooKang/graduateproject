package graduation.work.eatingalone;

public class NotiInfo {

    //주문 인덱스(키값)
    private String m_INDEX_KEY;

    //공지 제목
    private String m_NOTI_TITLE;

    //공지 내용
    private String m_NOTI_CONTENTS;

    //공지 날짜
    private String m_NOTI_DATE;

    public void setINDEX_KEY(String INDEX_KEY)
    {
        this.m_INDEX_KEY = INDEX_KEY;
    }
    public void setNOTI_TITLE(String NOTI_TITLE)
    {
        this.m_NOTI_TITLE = NOTI_TITLE;
    }
    public void setNOTI_CONTENTS(String NOTI_CONTENTS)
    {
        this.m_NOTI_CONTENTS = NOTI_CONTENTS;
    }
    public void setNOTI_DATE(String NOTI_DATE)
    {
        this.m_NOTI_DATE = NOTI_DATE;
    }

    public String getINDEX_KEY(){
        return m_INDEX_KEY;
    }
    public String getNOTI_TITLE(){
        return m_NOTI_TITLE;
    }
    public String getNOTI_CONTENTS(){
        return m_NOTI_CONTENTS;
    }
    public String getNOTI_DATE(){
        return m_NOTI_DATE;
    }
}
