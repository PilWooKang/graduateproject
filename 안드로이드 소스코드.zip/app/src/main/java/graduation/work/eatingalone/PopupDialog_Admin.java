package graduation.work.eatingalone;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

/**
 * 메인 메뉴 팝업
 */
public class PopupDialog_Admin extends Dialog implements View.OnClickListener {

    private Context mContext;

    private Button btnMenuModify, /*btnSeat,*/ btnOrder, btnPayment, btnRevenue, btnNoti;

    public interface OnDialogResult{

        void finish(int nAction);
    }
    OnDialogResult mDialogResult;

    public void setDialogResult(OnDialogResult dialogResult){

        mDialogResult = dialogResult;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowManager.LayoutParams lpWindow = new WindowManager.LayoutParams();
        lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        lpWindow.dimAmount = 0.6f;
        getWindow().setAttributes(lpWindow);

        setContentView(R.layout.dialog_popup_admin);

        /*
        DisplayMetrics displayMetrics = new DisplayMetrics();
        this.getWindow().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int deviceWidth = displayMetrics.widthPixels;
        int deviceHeight = displayMetrics.heightPixels;

        LinearLayout ll = (LinearLayout)findViewById(R.id.apa_layout);

        int popupWidth = (int)(deviceWidth * 0.5);
        int popupHeight = (int)(deviceHeight * 0.7);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(popupWidth, popupHeight);
        lp.gravity = Gravity.CENTER;

        ll.setLayoutParams(lp);
        */

        /*
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        View decorView = getWindow().getDecorView();
        this.overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
        */

        btnMenuModify = findViewById(R.id.dpa_btn_menu_modify);
        btnMenuModify.setOnClickListener(this);

        /*
        btnSeat = findViewById(R.id.apa_btn_seat);
        btnSeat.setOnClickListener(this);
        */

        btnOrder = findViewById(R.id.dpa_btn_order);
        btnOrder.setOnClickListener(this);

        btnPayment = findViewById(R.id.dpa_btn_payment);
        btnPayment.setOnClickListener(this);

        btnRevenue = findViewById(R.id.dpa_btn_revenue);
        btnRevenue.setOnClickListener(this);

        btnNoti = findViewById(R.id.dpa_btn_noti);
        btnNoti.setOnClickListener(this);
    }

    public PopupDialog_Admin(Context context) {
        // Dialog 배경을 투명 처리 해준다.
        super(context , android.R.style.Theme_Translucent_NoTitleBar);

        mContext = context;
        //mValue = nValue;
    }

    @Override
    public void onClick(View v) {

        Intent intent = null;

        switch (v.getId())
        {
            case R.id.dpa_btn_menu_modify:
                if( mDialogResult != null ) {

                    mDialogResult.finish(Define.ACTION_MENU_MODIFY);
                    dismiss();
                }
                /*
                intent = new Intent(this, MenuListActivity_Admin.class);
                startActivity(intent);
                finish();
                */
                break;

                /*
            case R.id.apa_btn_seat:
                intent = new Intent(this, SeatActivity_Admin.class);
                startActivity(intent);
                finish();
                break;
                */

            case R.id.dpa_btn_order:
                if( mDialogResult != null ) {

                    mDialogResult.finish(Define.ACTION_ORDER_LIST);
                    dismiss();
                }
                /*
                intent = new Intent(this, OrderInfoListActivity.class);
                startActivity(intent);
                finish();
                */
                break;

            case R.id.dpa_btn_payment:
                if( mDialogResult != null ) {

                    mDialogResult.finish(Define.ACTION_PAYMENT_LIST);
                    dismiss();
                }
                /*
                intent = new Intent(this, PaymentInfoListActivity.class);
                startActivity(intent);
                finish();
                */
                break;

            /**
             * 매출내역추가
             */
            case R.id.dpa_btn_revenue:
                if( mDialogResult != null ) {

                    mDialogResult.finish(Define.ACTION_REVENUE_LIST);
                    dismiss();
                }
                break;
            /**
             * 공지사항추가
             */
            case R.id.dpa_btn_noti:
                if( mDialogResult != null ) {

                    mDialogResult.finish(Define.ACTION_NOTI_LIST);
                    dismiss();
                }
                break;
        }
    }
}
