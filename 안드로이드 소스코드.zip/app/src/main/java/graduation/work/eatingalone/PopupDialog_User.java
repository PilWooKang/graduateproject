package graduation.work.eatingalone;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

/**
 * 메인 메뉴 팝업
 */
public class PopupDialog_User extends Dialog implements View.OnClickListener {

    private Context mContext;

    private Button btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8;

    public interface OnDialogResult{

        void finish(int nAction);
    }
    OnDialogResult mDialogResult;

    public void setDialogResult(OnDialogResult dialogResult){

        mDialogResult = dialogResult;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowManager.LayoutParams lpWindow = new WindowManager.LayoutParams();
        lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        lpWindow.dimAmount = 0.6f;
        getWindow().setAttributes(lpWindow);

        setContentView(R.layout.dialog_popup_user);

        /*
        DisplayMetrics displayMetrics = new DisplayMetrics();
        this.getWindow().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int deviceWidth = displayMetrics.widthPixels;
        int deviceHeight = displayMetrics.heightPixels;

        LinearLayout ll = (LinearLayout)findViewById(R.id.apa_layout);

        int popupWidth = (int)(deviceWidth * 0.5);
        int popupHeight = (int)(deviceHeight * 0.7);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(popupWidth, popupHeight);
        lp.gravity = Gravity.CENTER;

        ll.setLayoutParams(lp);
        */

        btn0 = findViewById(R.id.dpu_btn0);
        btn0.setOnClickListener(this);

        btn1 = findViewById(R.id.dpu_btn1);
        btn1.setOnClickListener(this);

        btn2 = findViewById(R.id.dpu_btn2);
        btn2.setOnClickListener(this);

        btn3 = findViewById(R.id.dpu_btn3);
        btn3.setOnClickListener(this);

        btn4 = findViewById(R.id.dpu_btn4);
        btn4.setOnClickListener(this);

        btn5 = findViewById(R.id.dpu_btn5);
        btn5.setOnClickListener(this);

        btn6 = findViewById(R.id.dpu_btn6);
        btn6.setOnClickListener(this);

        btn7 = findViewById(R.id.dpu_btn7);
        btn7.setOnClickListener(this);

        btn8 = findViewById(R.id.dpu_btn8);
        btn8.setOnClickListener(this);
    }

    public PopupDialog_User(Context context) {
        // Dialog 배경을 투명 처리 해준다.
        super(context , android.R.style.Theme_Translucent_NoTitleBar);

        mContext = context;
        //mValue = nValue;
    }

    @Override
    public void onClick(View v) {

        Intent intent = null;

        switch (v.getId())
        {
            case R.id.dpu_btn0:
                if( mDialogResult != null ) {

                    mDialogResult.finish(Define.ACTION_MENU_0);
                    dismiss();
                }
                break;
            case R.id.dpu_btn1:
            case R.id.dpu_btn2:
            case R.id.dpu_btn3:
            case R.id.dpu_btn4:
            case R.id.dpu_btn5:
            case R.id.dpu_btn6:
            case R.id.dpu_btn7:
            case R.id.dpu_btn8:
                if( mDialogResult != null ) {

                    mDialogResult.finish(Define.ACTION_MENU_1);
                    dismiss();
                }
                break;
        }
    }
}
