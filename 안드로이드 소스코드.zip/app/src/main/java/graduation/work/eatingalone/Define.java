package graduation.work.eatingalone;

public class Define {

    public static final int REQ_PICK_FROM_ALBUM = 1;

    /**
     * 관리자 팝업 메뉴
     */
    public static final int ACTION_MENU_MODIFY = 1;
    public static final int ACTION_ORDER_LIST = 2;
    public static final int ACTION_PAYMENT_LIST = 3;
    public static final int ACTION_REVENUE_LIST = 4;
    public static final int ACTION_NOTI_LIST = 5;

    /**
     * 사용자 팝업 메뉴
     */
    public static final int ACTION_MENU_0 = 0;  //공지사항
    public static final int ACTION_MENU_1 = 1;  //지역선택

    /**
     * 사용자 정보
     */
    public static String IS_ADMIN = "";     //관리자 계정인지 판별
    public static String USER_NAME = "";
    public static String USER_PHONE = "";
    public static String USER_ID = "";
    public static String USER_SEX = "";

    public final static int MY_PERMISSION_REQUEST_CODE = 100;

    /**
     * 좌석 정보
     */
    public static final String SEAT_A = "Seat_A";
    public static final String SEAT_B = "Seat_B";
    public static final String SEAT_C = "Seat_C";
    public static final String SEAT_D = "Seat_D";
    public static final String SEAT_E = "Seat_E";
    public static final String SEAT_F = "Seat_F";
    public static final String SEAT_G = "Seat_G";
    public static final String SEAT_H = "Seat_H";
    public static final String SEAT_I = "Seat_I";
    public static final String SEAT_J = "Seat_J";
    public static final String SEAT_K = "Seat_K";
    public static final String SEAT_L = "Seat_L";

    /**
     * Firebase 회원정보
     */
    public static final String FB_MEMBER_INFO = "MEMBER_INFO";
    public static final String FB_NAME = "NAME";
    public static final String FB_PHONE = "PHONE";
    public static final String FB_ID = "ID";
    public static final String FB_PW = "PW";
    public static final String FB_SEX = "SEX";

    /**
     * Firebase 메뉴정보
     */
    public static final String FB_MENU_INFO = "MENU_INFO";
    public static final String FB_MENU = "MENU";
    public static final String FB_PRICE = "PRICE";
    public static final String FB_MENU_IMG_URL = "MENU_IMG_URL";

    /**
     * Firebase 주문정보(고객명/메뉴명/가격/좌석정보/시간)
     */
    public static final String FB_ORDER_INFO = "ORDER_INFO";
    public static final String FB_ORDER_MENU = "ORDER_MENU";                    //상품명(주문내용)
    public static final String FB_ORDER_PRICE = "ORDER_PRICE";                  //상품가격(주문가격)
    public static final String FB_ORDER_SEAT_NO = "SEAT_NO";                    //좌석번호
    public static final String FB_ORDER_DATE = "ORDER_DATE";                    //주문시각
    public static final String FB_PAYMENT_DATE = "PAYMENT_DATE";                //결제시각
    public static final String FB_PAYMENT_COMPLETE = "PAYMENT_COMPLETE";        //결제완료 유.무

    /**
     * Firebase 공지사항 정보(제목/날짜/내용)
     */
    public static final String FB_NOTI_INFO = "NOTI_INFO";
    public static final String FB_NOTI_TITLE = "NOTI_TITLE";
    public static final String FB_NOTI_CONTENTS = "NOTI_CONTENTS";
    public static final String FB_NOTI_DATE = "NOTI_DATE";

    /**
     * INTENT 정보(메뉴정보)
     */
    public static final String INTENT_MENU_INDEX_KEY  = "INTENT_MENU_INDEX_KEY";
    public static final String INTENT_MENU_NAME = "INTENT_MENU_NAME";
    public static final String INTENT_MENU_PRICE = "INTENT_MENU_PRICE";
    public static final String INTENT_MENU_IMG_URL = "INTENT_MENU_IMG_URL";

    /**
     * INTENT 정보(주문정보)
     */
    public static final String INTENT_ORDER_MENU = "INTENT_ORDER_MENU";
    public static final String INTENT_ORDER_PRICE = "INTENT_ORDER_PRICE";
    public static final String INTENT_ORDER_DATE = "INTENT_ORDER_DATE";
    public static final String INTENT_SEAT_NO = "INTENT_SEAT_NO";

    /**
     * INTENT 정보(결제내역)
     */
    public static final String INTENT_USER_NAME = "INTENT_USER_NAME";               //고객명
    public static final String INTENT_STORE_NAME = "INTENT_STORE_NAME";             //가맹점
    public static final String INTENT_PRODUCT_NAME = "INTENT_PRODUCT_NAME";         //상품명
    public static final String INTENT_CARD_NAME = "INTENT_CARD_NAME";               //카드사
    public static final String INTENT_PAYMENT_PRICE = "INTENT_PAYMENT_PRICE";       //결제금액
    public static final String INTENT_PAYMENT_DATE = "INTENT_PAYMENT_DATE";         //결제시각

    /**
     * INTENT 정보(공지사항)
     */
    public static final String INTENT_NOTI_TITLE = "INTENT_NOTI_TITLE";               //공지사항 제목
    public static final String INTENT_NOTI_CONTENTS = "INTENT_NOTI_CONTENTS";           //공지사항 내용
    public static final String INTENT_NOTI_DATE = "INTENT_NOTI_DATE";              //공지사항 날짜

}
