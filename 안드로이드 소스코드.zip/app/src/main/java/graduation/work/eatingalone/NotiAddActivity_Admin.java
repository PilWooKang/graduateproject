package graduation.work.eatingalone;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

/**
 * 공지사항 추가
 */
public class NotiAddActivity_Admin extends Activity implements View.OnClickListener {

    public static String TAG = "NotiAddActivity_Admin";

    private EditText edtTitle, edtContents;
    private Button btnAdd;

    /**
     * Firebase DB
     */
    private FirebaseDatabase mDatabase = null;
    private DatabaseReference mRefNotiInfo = null;
    private DataSnapshot mSnapNotiInfo = null;
    private ArrayList<Integer> mNotiKeyList = new ArrayList<Integer>();

    private ProgressDialog mProgressDialog = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noti_add);

        edtTitle = findViewById(R.id.ana_edt_noti_title);
        edtContents = findViewById(R.id.ana_edt_noti_contents);

        /*
        edtPrice.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                // 입력되는 텍스트에 변화가 있을 때
            }

            @Override
            public void afterTextChanged(Editable arg0) {

                // 입력이 끝났을 때
                if(arg0.toString().equals("") == false)
                    nPrice = Integer.parseInt(arg0.toString());
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                // 입력하기 전에
            }
        });
        */
        btnAdd = findViewById(R.id.ana_btn_add);
        btnAdd.setOnClickListener(this);

        // Write a message to the database
        mDatabase = FirebaseDatabase.getInstance();

        mRefNotiInfo = mDatabase.getReference(Define.FB_NOTI_INFO);
        // Read from the database
        mRefNotiInfo.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                mSnapNotiInfo = dataSnapshot;

                mNotiKeyList = new ArrayList<Integer>();
                for (DataSnapshot child : mSnapNotiInfo.getChildren()) {

                    String key = "";
                    key = child.getKey();
                    mNotiKeyList.add(Integer.parseInt(key));
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }

    @Override
    public void onClick(View v) {

        Intent intent = null;

        switch (v.getId())
        {
            case R.id.ana_btn_add:

                String strTitle = edtTitle.getText().toString();
                String strContents = edtContents.getText().toString();

                if(mSnapNotiInfo == null)
                {
                    Toast.makeText(this, "Firebase 정보 동기화중", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(strTitle.equals(""))
                {
                    Toast.makeText(this, "제목을 입력해 주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(strContents.equals(""))
                {
                    Toast.makeText(this, "내용을 입력해 주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }

                mProgressDialog = new ProgressDialog(this);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                mProgressDialog.setMessage("공지사항 업로드중입니다.\n잠시만 기다려 주십시오.");
                mProgressDialog.setCancelable(false);
                mProgressDialog.setCanceledOnTouchOutside(false);
                mProgressDialog.show();

                int nKeyMax = 0;
                if(mNotiKeyList.size() > 0)
                    nKeyMax = (Collections.max(mNotiKeyList)).intValue();

                mProgressDialog.dismiss();
                mProgressDialog = null;

                // 시스템으로부터 현재시간(ms) 가져오기
                long now = System.currentTimeMillis();
                // Data 객체에 시간을 저장한다.
                Date date = new Date(now);
                // 각자 사용할 포맷을 정하고 문자열로 만든다.
                SimpleDateFormat sdfNow = new SimpleDateFormat("yyyy-MM-dd kk:mm");
                String strDate = sdfNow.format(date);

                mRefNotiInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_NOTI_TITLE).setValue(strTitle);
                mRefNotiInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_NOTI_CONTENTS).setValue(strContents);
                mRefNotiInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_NOTI_DATE).setValue(strDate);

                Toast.makeText(NotiAddActivity_Admin.this, "공지사항 추가 완료", Toast.LENGTH_SHORT).show();
                finish();
                break;
        }
    }
}
