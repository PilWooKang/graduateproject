package graduation.work.eatingalone;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Map;

public class OrderActivity_User extends Activity implements View.OnClickListener{

    public static String TAG = "OrderActivity_User";

    private TextView txtOrderMenu, txtOrderPrice, txtSeatNo, txtPaymentPrice;
    private Button btnComplete;

    private String intentSeatNo = "", intentOrderMenu = "", intentOrderPrice = "";

    private FirebaseDatabase mDatabase = null;
    private DatabaseReference mRefOrderInfo = null;
    private DataSnapshot mSnapOrderInfo = null;
    private ArrayList<Integer> mKeyListOrder = new ArrayList<Integer>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_user);

        intentOrderMenu = getIntent().getStringExtra(Define.INTENT_ORDER_MENU);
        intentOrderPrice = getIntent().getStringExtra(Define.INTENT_ORDER_PRICE);
        intentSeatNo = getIntent().getStringExtra(Define.INTENT_SEAT_NO);

        txtOrderMenu = findViewById(R.id.aou_txt_order_menu);
        if(intentOrderMenu != null)
            txtOrderMenu.setText(intentOrderMenu);

        txtOrderPrice = findViewById(R.id.aou_txt_menu_price);
        if(intentOrderPrice != null)
            txtOrderPrice.setText(intentOrderPrice);

        txtSeatNo = findViewById(R.id.aou_txt_seat_no);
        if(intentSeatNo != null) {
            txtSeatNo.setText(intentSeatNo);
        }

        txtPaymentPrice = findViewById(R.id.aou_txt_payment_price);
        if(intentOrderPrice != null)
            txtPaymentPrice.setText(intentOrderPrice);

        btnComplete = findViewById(R.id.aou_btn_complete);
        btnComplete.setOnClickListener(this);

        // Write a message to the database
        mDatabase = FirebaseDatabase.getInstance();
        mRefOrderInfo = mDatabase.getReference(Define.FB_ORDER_INFO);/*.child(Define.PHONE_NUM);*/

        // Read from the database
        mRefOrderInfo.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                mSnapOrderInfo = dataSnapshot;
                mKeyListOrder = new ArrayList<Integer>();
                String FBUserId = "", FBUserName = "", FBSeatNo = "", FBOrderMenu = "", FBOrderDate = "";

                for (DataSnapshot child : mSnapOrderInfo.getChildren()) {

                    String key = "";
                    key = child.getKey();
                    mKeyListOrder.add(Integer.parseInt(key));

                    JSONObject jsonObj = new JSONObject((Map)child.getValue());
                    if(jsonObj == null)
                        continue;

                    try {
                        FBUserId = (String) jsonObj.get(Define.FB_ID);
                        FBUserName = (String) jsonObj.get(Define.FB_NAME);
                        FBSeatNo = (String) jsonObj.get(Define.FB_ORDER_SEAT_NO);
                        FBOrderMenu = (String) jsonObj.get(Define.FB_ORDER_MENU);
                        FBOrderDate = (String) jsonObj.get(Define.FB_ORDER_DATE);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }

    @Override
    public void onClick(View view) {

        Intent intent = null;
        int nKeyMax = 0;

        switch (view.getId())
        {
            case R.id.aou_btn_complete:
                if(mSnapOrderInfo == null) {
                    Toast.makeText(this, "Firebase 정보 동기화중...", Toast.LENGTH_SHORT).show();
                    return;
                }
                nKeyMax = 0;
                if(mKeyListOrder.size() > 0)
                    nKeyMax = (Collections.max(mKeyListOrder)).intValue();

                // 시스템으로부터 현재시간(ms) 가져오기
                long now = System.currentTimeMillis();
                // Data 객체에 시간을 저장한다.
                Date date = new Date(now);
                // 각자 사용할 포맷을 정하고 문자열로 만든다.
                SimpleDateFormat sdfNow = new SimpleDateFormat("yyyy-MM-dd kk:mm");
                String strDate = sdfNow.format(date);

                mRefOrderInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_ID).setValue(Define.USER_ID);
                mRefOrderInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_NAME).setValue(Define.USER_NAME);
                mRefOrderInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_ORDER_MENU).setValue(intentOrderMenu);
                mRefOrderInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_ORDER_PRICE).setValue(intentOrderPrice);
                mRefOrderInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_ORDER_SEAT_NO).setValue(intentSeatNo);
                mRefOrderInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_ORDER_DATE).setValue(strDate);
                mRefOrderInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_PAYMENT_DATE).setValue("");
                mRefOrderInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_PAYMENT_COMPLETE).setValue("FALSE");
                Toast.makeText(this, "주문 완료!", Toast.LENGTH_SHORT).show();
                finish();
                break;
        }
    }
}
