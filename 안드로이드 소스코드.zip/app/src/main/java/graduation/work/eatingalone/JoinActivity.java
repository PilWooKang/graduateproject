package graduation.work.eatingalone;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

public class JoinActivity extends Activity implements View.OnClickListener{

    public static String TAG = "JoinActivity";

    private EditText edtName, edtPhone, edtId, edtPw, edtPw2;
    private Spinner spinSex;
    private Button btnJoin;
    private String mSex = "";

    private FirebaseDatabase mDatabase = null;
    private DatabaseReference mRefMemberInfo;
    private DataSnapshot mSnapMemberInfo = null;

    private ArrayList<Integer> mMemberKeyList = new ArrayList<Integer>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);

        edtName = findViewById(R.id.aj_edt_name);
        edtPhone = findViewById(R.id.aj_edt_phone);
        edtPhone.setText(Define.USER_PHONE);
        edtId = findViewById(R.id.aj_edt_id);
        edtPw = findViewById(R.id.aj_edt_pw);
        edtPw2 = findViewById(R.id.aj_edt_pw2);

        spinSex = (Spinner)findViewById(R.id.aj_spin_sex);
        spinSex.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {

                mSex = (String) parent.getItemAtPosition(position);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        btnJoin = findViewById(R.id.aj_btn_join);
        btnJoin.setOnClickListener(this);

        // Write a message to the database
        mDatabase = FirebaseDatabase.getInstance();
        mRefMemberInfo = mDatabase.getReference(Define.FB_MEMBER_INFO);

        // Read from the database
        mRefMemberInfo.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.

                mSnapMemberInfo = dataSnapshot;
                mMemberKeyList = new ArrayList<>();

                for (DataSnapshot child : mSnapMemberInfo.getChildren()) {

                    String key = "";
                    key = child.getKey();
                    mMemberKeyList.add(Integer.parseInt(key));
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
    }

    @Override
    public void onClick(View view) {

        switch (view.getId())
        {
            case R.id.aj_btn_join:

                String strName = edtName.getText().toString();
                String strPhone = edtPhone.getText().toString();
                String strSex = mSex;
                String strId = edtId.getText().toString();
                String strPw = edtPw.getText().toString();
                String strPw2 = edtPw2.getText().toString();

                if(mSnapMemberInfo == null) {
                    Toast.makeText(this, "Firebase 정보 동기화중...", Toast.LENGTH_SHORT).show();
                    return;
                }
                boolean joinedId = false;

                if(strName.equals(""))
                {
                    Toast.makeText(this, "이름을 입력해 해주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(strPhone.equals(""))
                {
                    Toast.makeText(this, "휴대폰 번호를 입력해 해주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(strSex.equals(""))
                {
                    Toast.makeText(this, "성별을 입력해 해주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(strId.equals(""))
                {
                    Toast.makeText(this, "아이디를 입력해 해주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(strPw.equals(""))
                {
                    Toast.makeText(this, "비밀번호를 입력 해주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(strPw.equals(strPw2) == false)
                {
                    Toast.makeText(this, "비밀번호를 재입력 해주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }

                for (DataSnapshot child : mSnapMemberInfo.getChildren()) {

                    String key = "";
                    key = child.getKey();

                    JSONObject jsonObj = new JSONObject((Map) child.getValue());
                    if (jsonObj == null)
                        continue;

                    try {
                        String FB_MemberId = (String) jsonObj.get(Define.FB_ID);

                        if(strId.equals(FB_MemberId))
                        {
                            Toast.makeText(this, "아이디가 이미 존재합니다.", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                int nKeyMax = 0;
                if(mMemberKeyList.size() > 0)
                    nKeyMax = (Collections.max(mMemberKeyList)).intValue();

                //회원가입시 자신의 휴대폰 번호를 Key로 사용한다.
                mRefMemberInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_NAME).setValue(strName);
                mRefMemberInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_PHONE).setValue(strPhone);
                mRefMemberInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_ID).setValue(strId);
                mRefMemberInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_PW).setValue(strPw);
                mRefMemberInfo.child(Integer.toString(nKeyMax + 1)).child(Define.FB_SEX).setValue(strSex);
                Toast.makeText(this, "회원가입 완료!", Toast.LENGTH_SHORT).show();
                finish();
                break;
        }
    }
}
