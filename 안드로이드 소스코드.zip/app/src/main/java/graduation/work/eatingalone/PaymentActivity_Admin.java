package graduation.work.eatingalone;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PaymentActivity_Admin extends Activity implements View.OnClickListener{

    public static String TAG = "PaymentActivity_Admin";

    private Button btnOk;

    private TextView txtUserName, txtStoreName, txtProductName, txtCardName, txtPaymentPrice, txtPaymentDate;

    private String intentUserName = "", intentStoreName = "", intentProductName = "", intentCardName = "", intentPaymentPrice = "", intentPaymentDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_admin);

        intentUserName = getIntent().getStringExtra(Define.INTENT_USER_NAME);
        intentStoreName = getIntent().getStringExtra(Define.INTENT_STORE_NAME);
        intentProductName = getIntent().getStringExtra(Define.INTENT_PRODUCT_NAME);
        intentCardName = getIntent().getStringExtra(Define.INTENT_CARD_NAME);
        intentPaymentPrice = getIntent().getStringExtra(Define.INTENT_PAYMENT_PRICE);
        intentPaymentDate = getIntent().getStringExtra(Define.INTENT_PAYMENT_DATE);

        txtUserName = findViewById(R.id.apa_txt_user_name);
        if(intentUserName != null)
            txtUserName.setText(intentUserName);

        txtStoreName = findViewById(R.id.apa_txt_store_name);
        if(intentStoreName != null)
            txtStoreName.setText(intentStoreName);

        txtProductName = findViewById(R.id.apa_txt_product_name);
        if(intentProductName != null)
            txtProductName.setText(intentProductName);

        txtCardName = findViewById(R.id.apa_txt_card_name);
        if(intentCardName != null)
            txtCardName.setText(intentCardName);

        txtPaymentPrice = findViewById(R.id.apa_txt_payment_price);
        if(intentPaymentPrice != null)
            txtPaymentPrice.setText(intentPaymentPrice);

        txtPaymentDate = findViewById(R.id.apa_txt_payment_date);
        if(intentPaymentDate != null)
            txtPaymentDate.setText(intentPaymentDate);

        btnOk = findViewById(R.id.apa_btn_ok);
        btnOk.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        Intent intent = null;

        switch (view.getId())
        {
            case R.id.apa_btn_ok:
                finish();
                break;
        }
    }
}
